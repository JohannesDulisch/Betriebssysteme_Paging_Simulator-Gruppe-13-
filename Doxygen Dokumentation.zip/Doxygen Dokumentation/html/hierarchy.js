var hierarchy =
[
    [ "des::CompareEvent", "structdes_1_1_compare_event.html", null ],
    [ "des::Event", "structdes_1_1_event.html", null ],
    [ "des::EventQueue", "classdes_1_1_event_queue.html", null ],
    [ "sim::MMU", "classsim_1_1_m_m_u.html", null ],
    [ "PageTable", "class_page_table.html", null ],
    [ "sim::PageTable", "classsim_1_1_page_table.html", null ],
    [ "PageTableEntry", "struct_page_table_entry.html", null ],
    [ "sim::PageTableEntry", "structsim_1_1_page_table_entry.html", null ],
    [ "PagingAlgorithm", "class_paging_algorithm.html", [
      [ "FIFOAlgorithm", "class_f_i_f_o_algorithm.html", null ],
      [ "LRUAlgorithm", "class_l_r_u_algorithm.html", null ],
      [ "NFUAgingAlgorithm", "class_n_f_u_aging_algorithm.html", null ],
      [ "NFUAlgorithm", "class_n_f_u_algorithm.html", null ],
      [ "NRUAlgorithm", "class_n_r_u_algorithm.html", null ],
      [ "SecondChanceAlgorithm", "class_second_chance_algorithm.html", null ]
    ] ],
    [ "sim::Process", "classsim_1_1_process.html", null ],
    [ "sim::Statistics", "classsim_1_1_statistics.html", null ],
    [ "sim::TLB", "classsim_1_1_t_l_b.html", null ],
    [ "sim::TLBEntry", "structsim_1_1_t_l_b_entry.html", null ]
];