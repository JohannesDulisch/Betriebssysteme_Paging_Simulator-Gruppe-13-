var namespacedes =
[
    [ "CompareEvent", "structdes_1_1_compare_event.html", "structdes_1_1_compare_event" ],
    [ "Event", "structdes_1_1_event.html", "structdes_1_1_event" ],
    [ "EventQueue", "classdes_1_1_event_queue.html", "classdes_1_1_event_queue" ],
    [ "EventType", "namespacedes.html#a16f107ef9061031dc11979acac6ae9d5", [
      [ "PAGE_ACCESS", "namespacedes.html#a16f107ef9061031dc11979acac6ae9d5add5ffcb7c4b64314070b2fee5337d765", null ]
    ] ]
];