var class_n_f_u_algorithm =
[
    [ "on_page_access", "class_n_f_u_algorithm.html#aa9add132c218799726ef1439775d5735", null ],
    [ "on_page_fault", "class_n_f_u_algorithm.html#ae3b8183255a1001058fa186024659940", null ],
    [ "select_victim", "class_n_f_u_algorithm.html#a4b43d770d1f4f6a7040e8d79752ef18b", null ]
];