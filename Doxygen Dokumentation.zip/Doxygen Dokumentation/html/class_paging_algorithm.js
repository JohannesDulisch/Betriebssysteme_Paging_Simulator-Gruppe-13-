var class_paging_algorithm =
[
    [ "~PagingAlgorithm", "class_paging_algorithm.html#aeb4dedbfcc2829956fb40ba3be36ff3e", null ],
    [ "on_page_access", "class_paging_algorithm.html#aeb16345b25ec35a17aa0a8ab1e8c78e7", null ],
    [ "on_page_fault", "class_paging_algorithm.html#ac708f9c42a51a3ded4d65c89c86198c6", null ],
    [ "select_victim", "class_paging_algorithm.html#ae22ca79e08ea7763b436cf6fdb7388cc", null ]
];