var searchData=
[
  ['valid_0',['valid',['../structsim_1_1_t_l_b_entry.html#a6dcd1fd2531913e291fddad1f2965b93',1,'sim::TLBEntry::valid'],['../structsim_1_1_page_table_entry.html#a985adf6fed49d07b5b68d7faead69b7b',1,'sim::PageTableEntry::valid'],['../struct_page_table_entry.html#a985adf6fed49d07b5b68d7faead69b7b',1,'PageTableEntry::valid']]]
];
