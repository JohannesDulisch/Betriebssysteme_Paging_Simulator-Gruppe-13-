var searchData=
[
  ['nfuagingalgorithm_0',['NFUAgingAlgorithm',['../class_n_f_u_aging_algorithm.html',1,'NFUAgingAlgorithm'],['../class_n_f_u_aging_algorithm.html#adcac7d8f7746631268e1f15b4c97d8d1',1,'NFUAgingAlgorithm::NFUAgingAlgorithm()']]],
  ['nfualgorithm_1',['NFUAlgorithm',['../class_n_f_u_algorithm.html',1,'']]],
  ['nrualgorithm_2',['NRUAlgorithm',['../class_n_r_u_algorithm.html',1,'NRUAlgorithm'],['../class_n_r_u_algorithm.html#a97adda9f52cce2a6637d19471cff9669',1,'NRUAlgorithm::NRUAlgorithm()']]]
];
