var searchData=
[
  ['algorithms_2ecpp_0',['algorithms.cpp',['../algorithms_8cpp.html',1,'']]],
  ['algorithms_2eh_1',['algorithms.h',['../algorithms_8h.html',1,'']]]
];
