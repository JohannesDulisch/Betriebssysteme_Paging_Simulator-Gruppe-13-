var searchData=
[
  ['nfuagingalgorithm_0',['NFUAgingAlgorithm',['../class_n_f_u_aging_algorithm.html',1,'']]],
  ['nfualgorithm_1',['NFUAlgorithm',['../class_n_f_u_algorithm.html',1,'']]],
  ['nrualgorithm_2',['NRUAlgorithm',['../class_n_r_u_algorithm.html',1,'']]]
];
