var searchData=
[
  ['invalidate_0',['invalidate',['../classsim_1_1_t_l_b.html#ad78e11ef4dea0b4707c832d965607ba2',1,'sim::TLB::invalidate()'],['../classsim_1_1_page_table.html#a49e6febe83b0a6a96d166bae8b540d84',1,'sim::PageTable::invalidate()'],['../class_page_table.html#a49e6febe83b0a6a96d166bae8b540d84',1,'PageTable::invalidate()']]],
  ['is_5fvalid_1',['is_valid',['../classsim_1_1_page_table.html#a340be48a7f550a0a16e55d00cf1c6f69',1,'sim::PageTable::is_valid()'],['../class_page_table.html#a340be48a7f550a0a16e55d00cf1c6f69',1,'PageTable::is_valid()']]],
  ['is_5fvalid_5findex_2',['is_valid_index',['../classsim_1_1_page_table.html#a4b81faec5389dceb4b65e38f0f9acb84',1,'sim::PageTable::is_valid_index()'],['../class_page_table.html#a4b81faec5389dceb4b65e38f0f9acb84',1,'PageTable::is_valid_index()']]]
];
