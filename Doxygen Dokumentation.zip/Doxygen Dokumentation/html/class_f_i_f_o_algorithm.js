var class_f_i_f_o_algorithm =
[
    [ "on_page_access", "class_f_i_f_o_algorithm.html#a11385085fbf93f2283be6b0200cf04a2", null ],
    [ "on_page_fault", "class_f_i_f_o_algorithm.html#adc0bfe14df483fcf7fffa1d8586857d9", null ],
    [ "select_victim", "class_f_i_f_o_algorithm.html#a4f0f4cc797395386e8a190c5b41b66c6", null ]
];