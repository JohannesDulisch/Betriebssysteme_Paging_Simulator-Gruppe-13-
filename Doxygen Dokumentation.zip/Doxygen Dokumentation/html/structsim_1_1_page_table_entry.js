var structsim_1_1_page_table_entry =
[
    [ "modified", "structsim_1_1_page_table_entry.html#ae16d0f1680b7fe6fc129c71ab872915b", null ],
    [ "page_id", "structsim_1_1_page_table_entry.html#a55ed7ded9151b3f101c22733fe71cb29", null ],
    [ "referenced", "structsim_1_1_page_table_entry.html#ad6dcb42a749e897e9d0f7848afe191de", null ],
    [ "valid", "structsim_1_1_page_table_entry.html#a985adf6fed49d07b5b68d7faead69b7b", null ]
];