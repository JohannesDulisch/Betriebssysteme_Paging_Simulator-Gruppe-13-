var classsim_1_1_process =
[
    [ "Process", "classsim_1_1_process.html#adbbf75d2968163adcaa8bdac2f68b3ef", null ],
    [ "getID", "classsim_1_1_process.html#ac097a71964b07158e3f0481b8b32d347", null ],
    [ "getPageTable", "classsim_1_1_process.html#a9f9cf8d14c23a7382acdeb243aa9782f", null ]
];