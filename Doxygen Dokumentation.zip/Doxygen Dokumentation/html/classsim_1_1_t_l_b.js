var classsim_1_1_t_l_b =
[
    [ "TLB", "classsim_1_1_t_l_b.html#a030ba7027d656c71d62f205f3f1c234a", null ],
    [ "clear", "classsim_1_1_t_l_b.html#a9d9fc3df35f85da97c363072a7ddcd69", null ],
    [ "invalidate", "classsim_1_1_t_l_b.html#ad78e11ef4dea0b4707c832d965607ba2", null ],
    [ "lookup", "classsim_1_1_t_l_b.html#a0cc87152c16e97d5a593ad2b823ae179", null ],
    [ "update", "classsim_1_1_t_l_b.html#a9a9fe8c192eaae58632fc17383b66d20", null ]
];