var dir_e86de6feb7f863c9ea75ae6e9166721e =
[
    [ "Desktop_Qt_6_7_3_MinGW_64_bit-Debug", "dir_fa9f83c98d64d4868ebc616f6f4e39fb.html", "dir_fa9f83c98d64d4868ebc616f6f4e39fb" ],
    [ "Desktop_Qt_6_9_0_MinGW_64_bit-Debug", "dir_7873163fb7428d555735428cdb545f4b.html", "dir_7873163fb7428d555735428cdb545f4b" ],
    [ "Qt_6_9_1_for_macOS-Debug", "dir_e935deeb5f737244d9e553e7a3cd8b71.html", "dir_e935deeb5f737244d9e553e7a3cd8b71" ]
];