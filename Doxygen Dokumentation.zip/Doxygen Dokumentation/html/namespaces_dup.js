var namespaces_dup =
[
    [ "des", "namespacedes.html", "namespacedes" ],
    [ "sim", "namespacesim.html", "namespacesim" ]
];