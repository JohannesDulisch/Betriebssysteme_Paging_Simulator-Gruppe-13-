#include "simulation.h"
#include <algorithm> // für std::find

namespace sim {

// ------ TLB ------

TLB::TLB(size_t max_size)
    : max_size_(max_size)
{}

bool TLB::lookup(int page_id) {
    auto it = entries_.find(page_id);
    return it != entries_.end() && it->second.valid;
}

void TLB::update(int page_id, int timestamp) {
    if (entries_.count(page_id)) {
        entries_[page_id] = {page_id, true, timestamp};
        return;
    }
    if (entries_.size() >= max_size_) {
        int victim = order_.front();
        order_.erase(order_.begin());
        entries_.erase(victim);
        std::cout << "TLB full -> evicting page " << victim << "\n";
    }
    entries_[page_id] = {page_id, true, timestamp};
    order_.push_back(page_id);
}

void TLB::invalidate(int page_id) {
    auto it = entries_.find(page_id);
    if (it == entries_.end()) return;

    entries_.erase(it);
    auto it2 = std::find(order_.begin(), order_.end(), page_id);
    if (it2 != order_.end()) order_.erase(it2);

    std::cout << "TLB invalidate page " << page_id << "\n";
}

void TLB::clear() {
    entries_.clear();
    order_.clear();
    std::cout << "TLB flushed\n";
}

// ------ PageTable ------

PageTable::PageTable(size_t pages_count)
    : pages_count_(pages_count),
    entries_(pages_count),
    valid_count_(0)
{
    for (size_t i = 0; i < pages_count_; ++i) {
        entries_[i] = { static_cast<int>(i), false, false, false };
    }
}

bool PageTable::is_valid(int page_id) const {
    return page_id >= 0
           && static_cast<size_t>(page_id) < pages_count_
           && entries_[page_id].valid;
}

void PageTable::set_valid(int page_id) {
    if (page_id >= 0 && static_cast<size_t>(page_id) < pages_count_) {
        auto& e = entries_[page_id];
        if (!e.valid) {
            e.valid = true;
            ++valid_count_;
        }
        e.referenced = true;
        e.modified   = false;
    }
}

void PageTable::invalidate(int page_id) {
    if (page_id >= 0 && static_cast<size_t>(page_id) < pages_count_) {
        auto& e = entries_[page_id];
        if (e.valid) {
            e.valid = false;
            --valid_count_;
        }
    }
}

size_t PageTable::size() const {
    return valid_count_;
}

void PageTable::set_referenced(int page_id, bool v) {
    if (page_id >= 0 && static_cast<size_t>(page_id) < pages_count_) {
        entries_[page_id].referenced = v;
    }
}




// ------ Process ------

Process::Process(int pid, size_t pages_count)
    : id_(pid),
    page_table_(pages_count)
{}

int Process::getID() const {
    return id_;
}

PageTable& Process::getPageTable() {
    return page_table_;
}

// ------ MMU (nur 1 Prozess) ------
void MMU::handle_event(const des::Event& e) {

    //ggf prüfen, ob virtuelle seite gültig ist
    if (e.page_id > process_.getPageTable().total_pages()) {
        std::cout << "virtual page with number " << e.page_id << " doesnt exist" << std::endl;
        return;
    }

    stats_.count_access();
    auto& pt = process_.getPageTable();

    // 🔍 TLB-Hit
    if (tlb_.lookup(e.page_id)) {
        std::cout << "TLB hit page " << e.page_id << std::endl;
        stats_.count_tlb_hit();
        pt.set_referenced(e.page_id, true);
        tlb_.update(e.page_id, e.timestamp);
        algo_.on_page_access(e.page_id);
        std::cout << "Event with timestamp " << e.timestamp << " processed" << std::endl;
        return;
    }

    // 📋 Page Table Hit
    if (pt.is_valid(e.page_id)) {
        std::cout << "Page table hit page " << e.page_id << std::endl;
        pt.set_referenced(e.page_id, true);
        tlb_.update(e.page_id, e.timestamp);
        algo_.on_page_access(e.page_id);
        std::cout << "Event with timestamp " << e.timestamp << " processed" << std::endl;
        return;
    }

    // ❗ Page Fault
    std::cout << "Page fault on page " << e.page_id << std::endl;
    stats_.count_page_fault();

    // Speicher voll? -> Opfer ersetzen
    if (pt.size() >= max_frames_) {
        int victim = algo_.select_victim();
        if (victim != -1) {
            std::cout << "Replacing page " << victim << std::endl;
            tlb_.invalidate(victim);
            pt.invalidate(victim);
            //algo_.on_evict(victim); // falls implementiert
        }
    }

    // Neue Seite laden
    pt.set_valid(e.page_id);
    pt.set_referenced(e.page_id, true);
    tlb_.update(e.page_id, e.timestamp);

    algo_.on_page_fault(e.page_id);
    algo_.on_page_access(e.page_id);

    std::cout << "Event with timestamp " << e.timestamp << " processed" << std::endl;
}


} // namespace sim
