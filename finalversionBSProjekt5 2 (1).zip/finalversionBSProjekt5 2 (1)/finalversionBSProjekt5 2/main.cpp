#include "discrete_event_simulation.h"
#include "simulation.h"
#include "algorithms.h"
#include <memory>
#include <iostream>
#include <thread>
#include <chrono>



int main() {
    using namespace des;
    using namespace sim;

    // 🔧 Konfigurierbare Parameter
    size_t tlb_size    = 2;
    size_t frame_count = 3;

    // Einziger Prozess (z. B. mit 5 virtuellen Seiten)
    Process proc1(1, 5);

    // Komponenten der Simulation
    EventQueue queue;
    TLB        tlb(tlb_size);
    Statistics stats;

    // 📌 Hier alle Algorithmus‑Objekte anlegen
    //auto algo = std::make_unique<NRUAlgorithm>(proc1.getPageTable());
    auto algo = std::make_unique<FIFOAlgorithm>();
    //auto algo = std::make_unique<SecondChanceAlgorithm>(proc1.getPageTable());
    //auto algo = std::make_unique<LRUAlgorithm>();
    //auto algo = std::make_unique<NFUAlgorithm>();
    //auto algo = std::make_unique<NFUAgingAlgorithm>(proc1.getPageTable());

    // MMU direkt mit dem einzigen Prozess verbinden
    MMU mmu(tlb, *algo, stats, frame_count, proc1);

    // Beispielhafte Ereignisse einplanen (process_id entfernt)
    queue.push({ 0,  EventType::PAGE_ACCESS, 1 });
    queue.push({ 1,  EventType::PAGE_ACCESS, 2 });
    queue.push({ 2,  EventType::PAGE_ACCESS, 3 });
    queue.push({ 3,  EventType::PAGE_ACCESS, 1 });
    queue.push({ 4,  EventType::PAGE_ACCESS, 1 });
    queue.push({ 5,  EventType::PAGE_ACCESS, 5 });
    queue.push({ 6,  EventType::PAGE_ACCESS, 1 });
    queue.push({ 7,  EventType::PAGE_ACCESS, 2 });
    queue.push({ 8,  EventType::PAGE_ACCESS, 6 });
    queue.push({ 9,  EventType::PAGE_ACCESS, 3 });
    queue.push({ 10, EventType::PAGE_ACCESS, 7 });
    queue.push({ 11, EventType::PAGE_ACCESS, 4 });



    // Parameter anzeigen, bevor die Events laufen
    std::cout << "===== Simulation Configuration =====\n"
              << "TLB size:          " << tlb_size    << "\n"
              << "Frame count:       " << frame_count << "\n"
              << "Virtuelle Seiten:  " << proc1.getPageTable().total_pages() << "\n"
              << "====================================\n\n";

    // Simulation ausführen
    queue.run([&](Event const& e) {
        std::cout << "---------------------------\n";
        mmu.handle_event(e);
    });


    // 2 Sekunden warten
    std::this_thread::sleep_for(std::chrono::seconds(1));
    // Statistik ausgeben
    stats.print();
    std::this_thread::sleep_for(std::chrono::seconds(1));

    return 0;
}
