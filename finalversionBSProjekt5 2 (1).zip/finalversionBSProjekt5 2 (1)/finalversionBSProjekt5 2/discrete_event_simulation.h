#ifndef DISCRETE_EVENT_SIMULATION_HPP
#define DISCRETE_EVENT_SIMULATION_HPP

#include <queue>
#include <vector>
#include <functional>
#include <stdexcept>

namespace des {

enum class EventType { PAGE_ACCESS };

struct Event {
    int       timestamp{};   // Zeitpunkt des Events
    EventType type{};        // Art des Events
    int       page_id{};     // betroffene Seite
    // process_id entfernt
};

struct CompareEvent {
    bool operator()(Event const& a, Event const& b) const noexcept {
        return a.timestamp > b.timestamp;
    }
};

class EventQueue {
public:
    // Neues Event einreihen (nimmt rvalue oder lvalue)
    void push(const Event& e) {
        events_.push(e);
    }
    void push(Event&& e) {
        events_.push(std::move(e));
    }

    bool empty() const noexcept {
        return events_.empty();
    }

    std::size_t size() const noexcept {
        return events_.size();
    }

    // Event entnehmen (mit Fehlerprüfung)
    Event pop() {
        if (empty()) {
            throw std::runtime_error("EventQueue::pop() called on empty queue");
        }
        Event e = std::move(const_cast<Event&>(events_.top())); // Move spart Kopie
        events_.pop();
        return e;
    }

    template<typename Handler>
    void step(Handler&& handler) {
        if (!empty()) {
            handler(pop());
        }
    }

    template<typename Handler>
    void run(Handler&& handler) {
        while (!empty()) {
            handler(pop());
        }
    }

private:
    std::priority_queue<Event, std::vector<Event>, CompareEvent> events_;
};

} // namespace des

#endif // DISCRETE_EVENT_SIMULATION_HPP
