/**
 * @file main.cpp
 * @brief Beispielhafte Ausführung der Paging-Simulation mit verschiedenen Algorithmen.
 *
 * Diese File erzeugt Prozesse, TLB, MMU, Events und führt die Simulation
 * unter Nutzung verschiedener Page-Replacement-Algorithmen durch.
 */

#include "discrete_event_simulation.h"
#include "simulation.h"
#include "algorithms.h"
#include <memory>
#include <iostream>
#include <thread>
#include <chrono>

using namespace des;
using namespace sim;

/**
 * @brief Beispielhafte Event-Queue erzeugen.
 * @param queue Referenz auf die EventQueue
 */
void createQueue(EventQueue& queue) {
    // Beispielhafte Ereignisse einplanen
    queue.push({ 0,  EventType::PAGE_ACCESS, 1 });
    queue.push({ 1,  EventType::PAGE_ACCESS, 2 });
    queue.push({ 2,  EventType::PAGE_ACCESS, 1 });
    queue.push({ 3,  EventType::PAGE_ACCESS, 4 });
    queue.push({ 4,  EventType::PAGE_ACCESS, 2 });
    queue.push({ 5,  EventType::PAGE_ACCESS, 5 });
    queue.push({ 6,  EventType::PAGE_ACCESS, 1 });
    queue.push({ 7,  EventType::PAGE_ACCESS, 2 });
    queue.push({ 8,  EventType::PAGE_ACCESS, 6 });
    queue.push({ 9,  EventType::PAGE_ACCESS, 3 });
    queue.push({ 10, EventType::PAGE_ACCESS, 7 });
    queue.push({ 11, EventType::PAGE_ACCESS, 4 });
}

/**
 * @brief Einstiegspunkt der Simulation.
 *
 * Erstellt Prozess, TLB, MMU, wählt Algorithmus aus, füllt EventQueue
 * und führt die Simulation aus. Am Ende werden Statistiken ausgegeben.
 *
 * @return 0 bei erfolgreicher Ausführung
 */
int main() {

    //  Konfigurierbare Parameter
    size_t tlb_size    = 2;
    size_t frame_count = 3;
    Process proc1(1, 8);     /**< Prozess mit ID 1 und 8 virtuellen Seiten */

    // Komponenten der Simulation
    EventQueue queue;
    TLB        tlb(tlb_size);
    Statistics stats;

    //  Algorithmus-Objekt anlegen
    //auto algo = std::make_unique<NRUAlgorithm>(proc1.getPageTable());
    auto algo = std::make_unique<FIFOAlgorithm>();
    //auto algo = std::make_unique<SecondChanceAlgorithm>(proc1.getPageTable());
    //auto algo = std::make_unique<LRUAlgorithm>();
    //auto algo = std::make_unique<NFUAlgorithm>();
    //auto algo = std::make_unique<NFUAgingAlgorithm>(proc1.getPageTable());

    // MMU anlegen
    MMU mmu(tlb, *algo, stats, frame_count, proc1);

    // Queue mit Events befüllen
    createQueue(queue);

    // Parameter anzeigen
    std::cout << "===== Simulation Configuration =====\n"
              << "TLB size:          " << tlb_size    << "\n"
              << "Frame count:       " << frame_count << "\n"
              << "Virtuelle Seiten:  " << proc1.getPageTable().total_pages() << "\n"
              << "Algo:              " << algo->getName() << "\n"
              << "====================================\n\n";

    // Simulation ausführen
    std::cout << "\n====== SIMULATION STARTET ================= \n\n";
    queue.run([&](Event const& e) {
        std::cout << "---------------------------------------------------\n";
        mmu.handle_event(e);
    });

    // Statistik ausgeben
    std::this_thread::sleep_for(std::chrono::seconds(1));
    std::cout << "\n====== SIMULATION BEENDET ================= \n\n\n";
    stats.print();
    std::this_thread::sleep_for(std::chrono::seconds(1));

    return 0;
}
