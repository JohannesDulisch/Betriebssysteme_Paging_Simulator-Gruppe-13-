/**
 * @file algorithms.hpp
 * @brief Enthält verschiedene Page-Replacement-Algorithmen für den Paging-Simulator.
 *
 * Diese Header-File definiert eine gemeinsame Schnittstelle (@ref PagingAlgorithm)
 * sowie konkrete Implementierungen klassischer Seitenersetzungs-Algorithmen:
 * - NRU (Not Recently Used)
 * - FIFO (First In, First Out)
 * - Second Chance
 * - LRU (Least Recently Used)
 * - NFU (Not Frequently Used)
 * - NFU mit Aging
 */

#ifndef ALGORITHMS_HPP
#define ALGORITHMS_HPP

#include <vector>
#include <unordered_map>
#include <climits>
#include <iostream>
#include <string>

namespace sim { class PageTable; }

/**
 * @class PagingAlgorithm
 * @brief Abstraktes Interface für Seitenersetzungs-Algorithmen.
 */
class PagingAlgorithm {
public:
    /**
     * @brief Reaktion auf einen Zugriff auf eine Seite.
     * @param page_id ID der zugegriffenen Seite.
     */
    virtual void on_page_access(int page_id) = 0;

    /**
     * @brief Reaktion auf einen Page-Fault (Seite muss geladen werden).
     * @param page_id ID der neu geladenen Seite.
     */
    virtual void on_page_fault(int page_id)  = 0;

    /**
     * @brief Auswahl einer zu entfernenden Seite bei vollem Speicher.
     * @return ID der zu entfernenden Seite oder -1, wenn keine vorhanden.
     */
    virtual int  select_victim()             = 0;

    /**
     * @brief Liefert den Namen des Algorithmus zurück.
     * @return Name des Algorithmus als String.
     */
    virtual std::string getName() const = 0;

    virtual ~PagingAlgorithm() = default;

};

/**
 * @class NRUAlgorithm
 * @brief Implementierung des NRU-Algorithmus (Not Recently Used).
 */
class NRUAlgorithm : public PagingAlgorithm {
public:
    /**
     * @brief Konstruktor.
     * @param pt Referenz auf die Seitentabelle.
     */
    explicit NRUAlgorithm(sim::PageTable& pt) : pt_(pt), name_("NRU") {}

    void on_page_access(int) override {}
    void on_page_fault(int) override {}
    int select_victim() override;

    /**
     * @brief Gibt den Namen des Algorithmus zurück.
     */
    std::string getName() const override { return name_; }

private:
    sim::PageTable& pt_; /**< Referenz auf die Seitentabelle */
    std::string name_;   /**< Name des Algorithmus */
};

/**
 * @class FIFOAlgorithm
 * @brief Implementierung des FIFO-Algorithmus (First In, First Out).
 */
class FIFOAlgorithm : public PagingAlgorithm {
public:
    FIFOAlgorithm() : name_("FIFO") {}

    void on_page_access(int) override {}
    void on_page_fault(int page_id) override { queue_.push_back(page_id); }

    int select_victim() override {
        if (queue_.empty()) return -1;
        int victim = queue_.front();
        queue_.erase(queue_.begin());

        std::cout << "[FIFO] Physischer Speicher voll -> entferne Seite " << victim << "\n";
        return victim;
    }

    /**
     * @brief Gibt den Namen des Algorithmus zurück.
     */
    std::string getName() const override { return name_; }

private:
    std::vector<int> queue_; /**< Warteschlange der Seiten in Lade-Reihenfolge */
    std::string name_;       /**< Name des Algorithmus */
};

/**
 * @class SecondChanceAlgorithm
 * @brief Implementierung des Second-Chance-Algorithmus.
 */
class SecondChanceAlgorithm : public PagingAlgorithm {
public:
    /**
     * @brief Konstruktor.
     * @param pt Referenz auf die Seitentabelle.
     */
    explicit SecondChanceAlgorithm(sim::PageTable& pt) : pt_(pt), name_("SecondChance") {}

    void on_page_access(int) override {}
    void on_page_fault(int page_id) override { queue_.push_back(page_id); }
    int select_victim() override;

    /**
     * @brief Gibt den Namen des Algorithmus zurück.
     */
    std::string getName() const override { return name_; }

private:
    sim::PageTable& pt_;        /**< Referenz auf die Seitentabelle */
    std::vector<int> queue_;    /**< Warteschlange der Seiten */
    size_t hand_ = 0;           /**< Aktuelle Position des "Uhrzeigers" */
    std::string name_;          /**< Name des Algorithmus */
};

/**
 * @class LRUAlgorithm
 * @brief Implementierung des LRU-Algorithmus (Least Recently Used).
 */
class LRUAlgorithm : public PagingAlgorithm {
public:
    LRUAlgorithm() : name_("LRU") {}

    void on_page_access(int page_id) override {
        timestamps_[page_id] = ++time_;
    }
    void on_page_fault(int) override {}

    int select_victim() override {
        if (timestamps_.empty()) return -1;
        int oldest = -1;
        int min_ts = INT_MAX;
        for (const auto& [page, ts] : timestamps_) {
            if (ts < min_ts) {
                min_ts = ts;
                oldest = page;
            }
        }
        std::cout << "[LRU] Physischer Speicher voll -> entferne Seite "
                  << oldest << " (zuletzt benutzt um Zeit " << min_ts << ")\n";

        timestamps_.erase(oldest);
        return oldest;
    }

    /**
     * @brief Gibt den Namen des Algorithmus zurück.
     */
    std::string getName() const override { return name_; }

private:
    std::unordered_map<int, int> timestamps_; /**< Zuordnung Seite -> letzter Zugriff */
    int time_ = 0;                            /**< Simulierte Zeit */
    std::string name_;                        /**< Name des Algorithmus */
};

/**
 * @class NFUAlgorithm
 * @brief Implementierung des NFU-Algorithmus (Not Frequently Used).
 */
class NFUAlgorithm : public PagingAlgorithm {
public:
    NFUAlgorithm() : name_("NFU") {}

    void on_page_access(int page_id) override { frequency_[page_id]++; }
    void on_page_fault(int page_id) override { frequency_[page_id] = 1; }

    int select_victim() override {
        if (frequency_.empty()) return -1;
        int min_freq = INT_MAX;
        int victim = -1;
        for (const auto& [page, freq] : frequency_) {
            if (freq < min_freq) {
                min_freq = freq;
                victim = page;
            }
        }

        std::cout << "[NFU] Physischer Speicher voll -> entferne Seite "
                  << victim << " (haeufigkeit = " << min_freq << ")\n";

        frequency_.erase(victim);
        return victim;
    }

    /**
     * @brief Gibt den Namen des Algorithmus zurück.
     */
    std::string getName() const override { return name_; }

private:
    std::unordered_map<int, int> frequency_; /**< Häufigkeitszähler pro Seite */
    std::string name_;                       /**< Name des Algorithmus */
};

/**
 * @class NFUAgingAlgorithm
 * @brief Implementierung von NFU mit Aging (Gleitende 8-Bit-Zähler).
 */
class NFUAgingAlgorithm : public PagingAlgorithm {
public:
    /**
     * @brief Konstruktor.
     * @param pt Referenz auf die Seitentabelle (wird hier nicht direkt benutzt).
     */
    explicit NFUAgingAlgorithm(sim::PageTable&) : name_("NFU-Aging") {}

    void on_page_access(int page_id) override {
        referenced_[page_id] = true;
        if (!counters_.count(page_id)) counters_[page_id] = 0;
    }

    void on_page_fault(int page_id) override {
        counters_[page_id]   = 0;
        referenced_[page_id] = true;
    }

    int select_victim() override {
        if (counters_.empty()) return -1;

        // Aging: 8-Bit-Fenster
        for (auto& kv : counters_) {
            int page = kv.first;
            int& ctr = kv.second;
            ctr = ((ctr >> 1) & 0x7F) | (referenced_[page] ? 0x80 : 0x00);
            referenced_[page] = false;
        }

        int victim = -1;
        int min_ctr = INT_MAX;
        for (const auto& [page, ctr] : counters_) {
            if (ctr < min_ctr) {
                min_ctr = ctr;
                victim = page;
            }
        }
        std::cout << "[NFU-Aging] Physischer Speicher voll -> entferne Seite "
                  << victim << " (zaehler=" << min_ctr << ")\n";

        counters_.erase(victim);
        referenced_.erase(victim);
        return victim;
    }

    /**
     * @brief Gibt den Namen des Algorithmus zurück.
     */
    std::string getName() const override { return name_; }

private:
    std::unordered_map<int, int>  counters_;   /**< Alterungszähler pro Seite */
    std::unordered_map<int, bool> referenced_; /**< Referenzbits für Aging */
    std::string name_;                         /**< Name des Algorithmus */
};

#endif // ALGORITHMS_HPP
