#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <vector>
#include <unordered_map>
#include <climits>
#include <iostream>

// Vorwärtsdeklaration im korrekten Namespace
namespace sim { class PageTable; }

// Paging-Algorithmus Interface
class PagingAlgorithm {
public:
    virtual void on_page_access(int page_id) = 0;
    virtual void on_page_fault(int page_id)  = 0;
    virtual int  select_victim()             = 0;
    virtual ~PagingAlgorithm() = default;
};

// --- NRU ---
class NRUAlgorithm : public PagingAlgorithm {
public:
    explicit NRUAlgorithm(sim::PageTable& pt) : pt_(pt) {}
    void on_page_access(int) override {}
    void on_page_fault(int) override {}
    int select_victim() override;

private:
    sim::PageTable& pt_;
};

// --- FIFO ---
class FIFOAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int) override {}
    void on_page_fault(int page_id) override { queue_.push_back(page_id); }

    int select_victim() override {
        int victim = queue_.front();
        queue_.erase(queue_.begin());
        std::cout << "[DEBUG] FIFO evicts page " << victim << "\n";
        return victim;
    }

private:
    std::vector<int> queue_;
};

// --- Second Chance ---
class SecondChanceAlgorithm : public PagingAlgorithm {
public:
    explicit SecondChanceAlgorithm(sim::PageTable& pt) : pt_(pt) {}

    void on_page_access(int) override {}
    void on_page_fault(int page_id) override { queue_.push_back(page_id); }

    int select_victim() override;

private:
    sim::PageTable& pt_;
    std::vector<int> queue_;
    size_t hand_ = 0;
};

// --- LRU ---
class LRUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override {
        timestamps_[page_id] = ++time_;
    }
    void on_page_fault(int) override {}
    int select_victim() override {
        int oldest = -1;
        int min_ts = INT_MAX;
        for (auto& [page, ts] : timestamps_) {
            if (ts < min_ts) {
                min_ts = ts;
                oldest = page;
            }
        }
        std::cout << "[DEBUG] LRU evicts page " << oldest
                  << " (last used at time " << min_ts << ")\n";
        timestamps_.erase(oldest);
        return oldest;
    }

private:
    std::unordered_map<int, int> timestamps_;
    int time_ = 0;
};

// --- NFU ---
class NFUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override { frequency_[page_id]++; }
    void on_page_fault(int page_id) override { frequency_[page_id] = 1; }

    int select_victim() override {
        int min_freq = INT_MAX, victim = -1;
        for (const auto& [page, freq] : frequency_) {
            if (freq < min_freq) {
                min_freq = freq;
                victim = page;
            }
        }
        std::cout << "[DEBUG] NFU evicts page " << victim
                  << " (frequency=" << min_freq << ")\n";
        frequency_.erase(victim);
        return victim;
    }

private:
    std::unordered_map<int, int> frequency_;
};

// --- NFU mit Aging ---
class NFUAgingAlgorithm : public PagingAlgorithm {
public:
    explicit NFUAgingAlgorithm(sim::PageTable& pt) : pt_(pt) {}

    void on_page_access(int) override {}
    void on_page_fault(int page_id) override {
        aging_[page_id] = 0;
    }

    int select_victim() override;

private:
    sim::PageTable& pt_; // aktuell nicht zwingend genutzt, aber verfügbar
    std::unordered_map<int, int> aging_;
};

#endif // ALGORITHMS_H
