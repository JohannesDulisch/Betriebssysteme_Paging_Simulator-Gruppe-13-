#include "algorithms.h"
#include "simulation.h"    // volle Definition von sim::PageTable & PageTableEntry
#include <limits>

using sim::PageTable;
using sim::PageTableEntry;

// Hilfsfunktion: Index eines page_id in der PageTable finden
namespace {
size_t find_index_by_page_id(const PageTable& pt, int page_id) {
    for (size_t i = 0; i < pt.total_pages(); ++i) {
        const auto& e = pt.entry(i);
        if (e.page_id == page_id) return i;
    }
    return static_cast<size_t>(-1);
}
}

// ================= NRU =================
int NRUAlgorithm::select_victim() {
    int victim_page = -1;
    int min_class = 4;

    for (size_t i = 0; i < pt_.total_pages(); ++i) {
        const auto &e = pt_.entry(i);
        if (!e.valid) continue; // nur gültige Seiten betrachten
        int cls = (e.referenced ? 2 : 0) + (e.modified ? 1 : 0); // 0..3
        if (cls < min_class) {
            min_class = cls;
            victim_page = e.page_id;
            if (min_class == 0) break; // beste Klasse gefunden
        }
    }
    std::cout << "[DEBUG] NRU evicts page " << victim_page
              << " (class=" << min_class << ")\n";
    return victim_page;
}

// ============== Second Chance ==========
int SecondChanceAlgorithm::select_victim() {
    if (queue_.empty()) return -1;
    hand_ %= queue_.size();

    while (true) {
        int page_id = queue_[hand_];
        size_t idx = find_index_by_page_id(pt_, page_id);

        bool referenced = false;
        if (idx != static_cast<size_t>(-1)) {
            referenced = pt_.entry(idx).referenced;
        }

        if (referenced) {
            // zweite Chance: Referenced-Bit löschen und weiter
            pt_.set_referenced(page_id, false);
            hand_ = (hand_ + 1) % queue_.size();
        } else {
            // Opfer wählen und aus der Queue entfernen
            int victim = page_id;
            queue_.erase(queue_.begin() + static_cast<std::ptrdiff_t>(hand_));
            if (!queue_.empty()) hand_ %= queue_.size();
            std::cout << "[DEBUG] SecondChance evicts page " << victim << "\n";
            return victim;
        }
    }
}

// ============== NFU Aging ==============
int NFUAgingAlgorithm::select_victim() {
    if (aging_.empty()) return -1;

    int victim = -1;
    int min_age = std::numeric_limits<int>::max();

    for (const auto& [page, age] : aging_) {
        if (age < min_age) {
            min_age = age;
            victim = page;
        }
    }
    std::cout << "[DEBUG] NFUAging evicts page " << victim
              << " (age=" << min_age << ")\n";
    aging_.erase(victim);
    return victim;
}
