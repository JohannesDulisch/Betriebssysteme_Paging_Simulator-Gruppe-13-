#ifndef ALGORITHMS_HPP
#define ALGORITHMS_HPP

#include <vector>
#include <unordered_map>
#include <climits>
#include <iostream>

namespace sim { class PageTable; }

// Paging-Algorithmus Interface
class PagingAlgorithm {
public:
    virtual void on_page_access(int page_id) = 0;
    virtual void on_page_fault(int page_id)  = 0;
    virtual int  select_victim()             = 0;
    virtual ~PagingAlgorithm() = default;
};

// --- NRU ---
class NRUAlgorithm : public PagingAlgorithm {
public:
    explicit NRUAlgorithm(sim::PageTable& pt) : pt_(pt) {}
    void on_page_access(int) override {}
    void on_page_fault(int) override {}
    int select_victim() override;
private:
    sim::PageTable& pt_;
};

// --- FIFO ---
class FIFOAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int) override {}
    void on_page_fault(int page_id) override { queue_.push_back(page_id); }

    int select_victim() override {
        if (queue_.empty()) return -1;
        int victim = queue_.front();
        queue_.erase(queue_.begin());

        std::cout << "[FIFO] Physischer Speicher voll -> entferne Seite " << victim << "\n";
        return victim;
    }
private:
    std::vector<int> queue_;
};

// --- Second Chance ---
class SecondChanceAlgorithm : public PagingAlgorithm {
public:
    explicit SecondChanceAlgorithm(sim::PageTable& pt) : pt_(pt) {}
    void on_page_access(int) override {}
    void on_page_fault(int page_id) override { queue_.push_back(page_id); }
    int select_victim() override;
private:
    sim::PageTable& pt_;
    std::vector<int> queue_;
    size_t hand_ = 0;
};

// --- LRU ---
class LRUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override {
        timestamps_[page_id] = ++time_;
    }
    void on_page_fault(int) override {}
    int select_victim() override {
        if (timestamps_.empty()) return -1;
        int oldest = -1;
        int min_ts = INT_MAX;
        for (const auto& [page, ts] : timestamps_) {
            if (ts < min_ts) {
                min_ts = ts;
                oldest = page;
            }
        }
        std::cout << "[LRU] Physischer Speicher voll -> entferne Seite " << oldest << " (zuletzt benutzt um Zeit " << min_ts << ")\n";

        timestamps_.erase(oldest);
        return oldest;
    }
private:
    std::unordered_map<int, int> timestamps_;
    int time_ = 0;
};

// --- NFU ---
class NFUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override { frequency_[page_id]++; }
    void on_page_fault(int page_id) override { frequency_[page_id] = 1; }
    int select_victim() override {
        if (frequency_.empty()) return -1;
        int min_freq = INT_MAX;
        int victim = -1;
        for (const auto& [page, freq] : frequency_) {
            if (freq < min_freq) {
                min_freq = freq;
                victim = page;
            }
        }

        std::cout << "[NFU] Physischer Speicher voll -> entferne Seite " << victim << " (haeufigkeit = " << min_freq << ")\n";

        frequency_.erase(victim);
        return victim;
    }
private:
    std::unordered_map<int, int> frequency_;
};

// --- NFU mit Aging ---
class NFUAgingAlgorithm : public PagingAlgorithm {
public:
    explicit NFUAgingAlgorithm(sim::PageTable&) {}

    void on_page_access(int page_id) override {
        referenced_[page_id] = true;
        if (!counters_.count(page_id)) counters_[page_id] = 0;
    }

    void on_page_fault(int page_id) override {
        counters_[page_id]   = 0;
        referenced_[page_id] = true;
    }

    int select_victim() override {
        if (counters_.empty()) return -1;

        // Aging: 8-Bit-Fenster
        for (auto& kv : counters_) {
            int page = kv.first;
            int& ctr = kv.second;
            ctr = ((ctr >> 1) & 0x7F) | (referenced_[page] ? 0x80 : 0x00);
            referenced_[page] = false;
        }

        int victim = -1;
        int min_ctr = INT_MAX;
        for (const auto& [page, ctr] : counters_) {
            if (ctr < min_ctr) {
                min_ctr = ctr;
                victim = page;
            }
        }
        std::cout << "[NFU-Aging] Physischer Speicher voll -> entferne Seite " << victim << " (zaehler=" << min_ctr << ")\n";

        counters_.erase(victim);
        referenced_.erase(victim);
        return victim;
    }
private:
    std::unordered_map<int, int>  counters_;
    std::unordered_map<int, bool> referenced_;
};

#endif // ALGORITHMS_HPP
