#ifndef SIMULATION_HPP
#define SIMULATION_HPP

#include "discrete_event_simulation.h"
#include "algorithms.h"
#include <iostream>
#include <unordered_map>
#include <vector>

namespace sim {

// --- Statistik ---
class Statistics {
public:
    void count_access()     { ++page_accesses_; }
    void count_tlb_hit()    { ++tlb_hits_; }
    void count_page_fault() { ++page_faults_; }

    void print() const {
        std::cout << "\n"
                  << "================ Statistik ================\n"
                  << "Seitenzugriffe: " << page_accesses_ << "\n"
                  << "TLB-Treffer:    " << tlb_hits_      << "\n"
                  << "Seitenfehler:   " << page_faults_   << "\n"
                  << "===========================================\n\n";
    }


private:
    int page_accesses_ = 0, tlb_hits_ = 0, page_faults_ = 0;
};

// --- TLB ---
struct TLBEntry { int page_id; bool valid; int timestamp; };

class TLB {
public:
    TLB(size_t max_size);
    bool lookup(int page_id);
    void update(int page_id, int timestamp);
    void invalidate(int page_id);
    void clear();

private:
    size_t max_size_;
    std::unordered_map<int, TLBEntry> entries_;

    int find_lru_page() const;
};


// --- Page Table ---
struct PageTableEntry {
    int  page_id;
    bool valid;
    bool referenced;
    bool modified;
};

class PageTable {
public:
    PageTable(size_t pages_count);

    bool is_valid(int page_id) const;
    void set_valid(int page_id);
    void invalidate(int page_id);
    size_t size() const;
    void set_referenced(int page_id, bool v);
    const PageTableEntry& entry(size_t idx) const { return entries_[idx]; }
    size_t total_pages() const { return pages_count_; }
    bool is_valid_index(int page_id) const;


private:
    size_t                              pages_count_;
    std::vector<PageTableEntry>        entries_;
    size_t                              valid_count_;
};

// --- Prozess ---
class Process {
public:
    Process(int pid, size_t pages_count);

    int        getID()         const;
    PageTable& getPageTable();

private:
    int       id_;
    PageTable page_table_;
};

// --- MMU ---
class MMU {
public:
    MMU(TLB& tlb, PagingAlgorithm& algo, Statistics& stats, size_t max_frames, Process& process)
        : tlb_(tlb),
        algo_(algo),
        stats_(stats),
        max_frames_(max_frames),
        process_(process) {}

    void handle_event(const des::Event& e);

private:
    TLB&             tlb_;
    PagingAlgorithm& algo_;
    Statistics&      stats_;
    size_t           max_frames_;
    Process&         process_;
};


} // namespace sim

#endif // SIMULATION_HPP
