#include "simulation.h"

namespace sim {

#include <iostream>  // für std::cout
#include <climits>   // für INT_MAX


// ------ TLB ------

TLB::TLB(size_t max_size)
    : max_size_(max_size)
{}

bool TLB::lookup(int page_id) {
    auto it = entries_.find(page_id);
    return it != entries_.end() && it->second.valid;
}

void TLB::update(int page_id, int timestamp) {
    if (entries_.count(page_id)) {
        // schon im TLB -> Timestamp erneuern
        entries_[page_id].timestamp = timestamp;
        entries_[page_id].valid     = true;
        //std::cout << "[TLB] Aktualisiere Eintrag fuer Seite " << page_id << " -> neuer Timestamp " << timestamp << "\n";
        return;
    }

    if (entries_.size() >= max_size_) {
        int victim = find_lru_page();
        entries_.erase(victim);
        //std::cout << "[TLB] Voll -> entferne LRU-Seite " << victim << "\n";
    }

    entries_[page_id] = { page_id, true, timestamp };
    //std::cout << "[TLB] Fuege Seite " << page_id << " hinzu (Timestamp " << timestamp << ")\n";
}

void TLB::invalidate(int page_id) {
    if (entries_.erase(page_id)) {
        std::cout << "[TLB] Loesche ebenfalls Eintrag für Seite " << page_id << "\n";
    } else {
        std::cout << "[TLB] Kein Eintrag fuer Seite " << page_id << " im TLB, keine Veraenderung noetig\n";
    }
}

void TLB::clear() {
    entries_.clear();
    //std::cout << "[TLB] Leere alle Eintraege\n";
}

int TLB::find_lru_page() const {
    int  oldest_page = -1;
    int  min_ts      = INT_MAX;
    for (auto const& [pid, entry] : entries_) {
        if (entry.valid && entry.timestamp < min_ts) {
            min_ts      = entry.timestamp;
            oldest_page = pid;
        }
    }
    return oldest_page;
}


// ------ PageTable ------

PageTable::PageTable(size_t pages_count)
    : pages_count_(pages_count),
    entries_(pages_count),
    valid_count_(0)
{
    for (size_t i = 0; i < pages_count_; ++i) {
        entries_[i] = { static_cast<int>(i), false, false, false };
    }
}

bool PageTable::is_valid_index(int page_id) const {
    return page_id >= 0 &&
           static_cast<size_t>(page_id) < pages_count_;
}

bool PageTable::is_valid(int page_id) const {
    bool in_mem = is_valid_index(page_id) && entries_[page_id].valid;
    //std::cout << "[PageTable] Seite " << page_id << " im physischen Speicher? -> " << (in_mem ? "Ja" : "Nein") << "\n";
    return in_mem;
}

void PageTable::set_valid(int page_id) {
    if (!is_valid_index(page_id)) {
        //std::cout << "[PageTable] Ungueltige Seite " << page_id << "\n";
        return;
    }

    auto& e = entries_[page_id];
    if (!e.valid) {
        e.valid = true;
        ++valid_count_;
        //std::cout << "[PageTable] Seite " << page_id << " geladen -> belegte Seiten: " << valid_count_ << "\n";
    }

    // Referenz- und Modified-Bit zurücksetzen
    e.referenced = false;
    e.modified   = false;
}

size_t PageTable::size() const {
    //std::cout << "[PageTable] Aktuell belegte Seiten: " << valid_count_ << "\n";
    return valid_count_;
}

void PageTable::invalidate(int page_id) {
    if (!is_valid_index(page_id)) {
        //std::cout << "[PageTable] Ungueltige Seite " << page_id << "\n";
        return;
    }

    auto& e = entries_[page_id];
    if (e.valid) {
        e.valid = false;
        --valid_count_;
        //std::cout << "[PageTable] Seite " << page_id << " entfernt -> verbleibende Seiten: " << valid_count_ << "\n";
    } else {
        //std::cout << "[PageTable] Seite " << page_id << " war nicht im physischen Speicher\n";
    }
}

void PageTable::set_referenced(int page_id, bool v) {
    if (!is_valid_index(page_id)) {
        //std::cout << "[PageTable] Ungueltige Seite " << page_id << "\n";
        return;
    }

    entries_[page_id].referenced = v;
    //std::cout << "[PageTable] Referenz-Bit gesetzt (" << (v ? 1 : 0) << ") fuer Seite " << page_id << "\n";
}


// ------ Process ------

Process::Process(int pid, size_t pages_count)
    : id_(pid),
    page_table_(pages_count)
{}

int Process::getID() const {
    return id_;
}

PageTable& Process::getPageTable() {
    return page_table_;
}




// ------ MMU (nur 1 Prozess) ------

void MMU::handle_event(const des::Event& e) {
    auto& pt = process_.getPageTable();

    std::cout << "[EVENT] Zugriff auf virtuelle Seite " << e.page_id
              << " (Timestamp: " << e.timestamp << ")\n";

    // 0) Ungültige Seite?
    if (!pt.is_valid_index(e.page_id)) {
        std::cout << "[MMU] Virtuelle Seite " << e.page_id
                  << " existiert nicht\n";
        return;
    }

    stats_.count_access();

    // 1) TLB-Treffer?
    if (tlb_.lookup(e.page_id)) {
        std::cout << "[MMU] TLB-Treffer fuer Seite " << e.page_id << "\n";
        stats_.count_tlb_hit();

        pt.set_referenced(e.page_id, true);
        algo_.on_page_access(e.page_id);

        tlb_.update(e.page_id, e.timestamp);

        std::cout << "[EVENT] Zugriff abgeschlossen (Timestamp: " << e.timestamp << ")\n";
        return;
    }
    std::cout << "[MMU] TLB-Miss fuer Seite " << e.page_id << "\n";

    // 2) Seitentabellen-Treffer?
    if (pt.is_valid(e.page_id)) {
        std::cout << "[MMU] Seitentabellen-Treffer fuer Seite " << e.page_id << "\n";

        pt.set_referenced(e.page_id, true);
        algo_.on_page_access(e.page_id);

        tlb_.update(e.page_id, e.timestamp);

        std::cout << "[EVENT] Zugriff abgeschlossen (Timestamp: " << e.timestamp << ")\n";
        return;
    }
    std::cout << "[MMU] Seitentabellen-Miss fuer Seite " << e.page_id << "\n";

    // 3) Seitenfehler
    std::cout << "[MMU] Seitenfehler fuer Seite " << e.page_id << "\n";
    stats_.count_page_fault();

    // a) Voller physischer Speicher?
    if (pt.size() >= max_frames_) {
        int victim = algo_.select_victim();
        if (victim != -1) {
            pt.invalidate(victim);
            tlb_.invalidate(victim);
        }
    }

    // b) Platz zum Laden?
    std::cout << "[MMU] Lade Seite " << e.page_id << " in den Physischen Speicher \n";

    pt.set_valid(e.page_id);
    pt.set_referenced(e.page_id, true);

    algo_.on_page_fault(e.page_id);
    algo_.on_page_access(e.page_id);

    tlb_.update(e.page_id, e.timestamp);


    std::cout << "[EVENT] Zugriff abgeschlossen (Timestamp: "
              << e.timestamp << ")\n";
}

} // namespace sim
