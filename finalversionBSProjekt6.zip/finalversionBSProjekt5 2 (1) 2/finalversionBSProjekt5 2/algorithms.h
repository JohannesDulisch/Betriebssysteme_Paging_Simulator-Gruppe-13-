#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <vector>
#include <unordered_map>
#include <climits>
#include <iostream>

// Vorwärtsdeklaration im korrekten Namespace
namespace sim { class PageTable; }

// Paging-Algorithmus Interface
class PagingAlgorithm {
public:
    virtual void on_page_access(int page_id) = 0;
    virtual void on_page_fault(int page_id)  = 0;
    virtual int  select_victim()             = 0;
    virtual ~PagingAlgorithm() = default;
};

// --- NRU ---
class NRUAlgorithm : public PagingAlgorithm {
public:
    explicit NRUAlgorithm(sim::PageTable& pt) : pt_(pt) {}
    void on_page_access(int) override {}
    void on_page_fault(int) override {}
    int select_victim() override;

private:
    sim::PageTable& pt_;
};

// --- FIFO ---
class FIFOAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int) override {}
    void on_page_fault(int page_id) override { queue_.push_back(page_id); }

    int select_victim() override {
        int victim = queue_.front();
        queue_.erase(queue_.begin());
        std::cout << "[DEBUG] FIFO evicts page " << victim << "\n";
        return victim;
    }

private:
    std::vector<int> queue_;
};

// --- Second Chance ---
class SecondChanceAlgorithm : public PagingAlgorithm {
public:
    explicit SecondChanceAlgorithm(sim::PageTable& pt) : pt_(pt) {}

    void on_page_access(int) override {}
    void on_page_fault(int page_id) override { queue_.push_back(page_id); }

    int select_victim() override;

private:
    sim::PageTable& pt_;
    std::vector<int> queue_;
    size_t hand_ = 0;
};

// --- LRU ---
class LRUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override {
        timestamps_[page_id] = ++time_;
    }
    void on_page_fault(int) override {}
    int select_victim() override {
        int oldest = -1;
        int min_ts = INT_MAX;
        for (auto& [page, ts] : timestamps_) {
            if (ts < min_ts) {
                min_ts = ts;
                oldest = page;
            }
        }
        std::cout << "[DEBUG] LRU evicts page " << oldest
                  << " (last used at time " << min_ts << ")\n";
        timestamps_.erase(oldest);
        return oldest;
    }

private:
    std::unordered_map<int, int> timestamps_;
    int time_ = 0;
};

// --- NFU ---
class NFUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override { frequency_[page_id]++; }
    void on_page_fault(int page_id) override { frequency_[page_id] = 1; }

    int select_victim() override {
        int min_freq = INT_MAX, victim = -1;
        for (const auto& [page, freq] : frequency_) {
            if (freq < min_freq) {
                min_freq = freq;
                victim = page;
            }
        }
        std::cout << "[DEBUG] NFU evicts page " << victim
                  << " (frequency=" << min_freq << ")\n";
        frequency_.erase(victim);
        return victim;
    }

private:
    std::unordered_map<int, int> frequency_;
};

// --- NFU mit Aging ---
class NFUAgingAlgorithm : public PagingAlgorithm {
public:
    // Behalte den ctor mit PageTable-Ref, damit dein bestehender make_unique-Aufruf weiter funktioniert.
    explicit NFUAgingAlgorithm(sim::PageTable&) {}

    void on_page_access(int page_id) override {
        // Zugriff merken
        referenced_[page_id] = true;

        // Falls die Seite noch keinen Zähler hat (kann bei ersten Zugriffen passieren)
        if (!counters_.count(page_id)) counters_[page_id] = 0;
    }

    void on_page_fault(int page_id) override {
        // Neue Seite bekommt Zähler 0 und gilt (in diesem Tick) als referenziert
        counters_[page_id]   = 0;
        referenced_[page_id] = true;
    }

    int select_victim() override {
        if (counters_.empty()) return -1;

        // 1) Aging-Schritt für alle bekannten Seiten: 8-Bit-Fenster simulieren
        for (auto& kv : counters_) {
            int page = kv.first;
            int& ctr = kv.second;
            // auf 8 Bits beschränken: rechts schieben + ggf. 0x80 setzen
            ctr = ((ctr >> 1) & 0x7F) | (referenced_[page] ? 0x80 : 0x00);
            referenced_[page] = false; // Ref-Flag für die nächste Runde löschen
        }

        // 2) Seite mit kleinster Nutzung wählen
        int victim = -1;
        int min_ctr = INT_MAX;
        for (const auto& [page, ctr] : counters_) {
            if (ctr < min_ctr) {
                min_ctr = ctr;
                victim = page;
            }
        }

        std::cout << "[DEBUG] NFUAging evicts page " << victim
                  << " (ctr=" << min_ctr << ")\n";

        // 3) Aus internen Strukturen entfernen
        counters_.erase(victim);
        referenced_.erase(victim);
        return victim;
    }

private:
    // Nur intern im Algorithmus: Seitenzähler + „referenced seit letzter Alterung“
    std::unordered_map<int, int>  counters_;
    std::unordered_map<int, bool> referenced_;
};

#endif // ALGORITHMS_H
