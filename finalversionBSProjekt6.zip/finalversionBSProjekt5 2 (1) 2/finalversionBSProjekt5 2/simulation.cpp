#include "simulation.h"

namespace sim {

// ------ TLB ------
TLB::TLB(size_t max_size)
    : max_size_(max_size)
{}

bool TLB::lookup(int page_id) {
    auto it = entries_.find(page_id);
    return it != entries_.end() && it->second.valid;
}

void TLB::update(int page_id, int timestamp) {
    if (entries_.count(page_id)) {
        // Seite ist schon drin → Timestamp aktualisieren
        entries_[page_id].timestamp = timestamp;
        entries_[page_id].valid = true;
        return;
    }

    if (entries_.size() >= max_size_) {
        int victim = find_lru_page();
        entries_.erase(victim);
        std::cout << "TLB full -> evicting page " << victim << "\n";
    }

    entries_[page_id] = {page_id, true, timestamp};
}

void TLB::invalidate(int page_id) {

    if (entries_.erase(page_id)) {
        std::cout << "TLB invalidate page " << page_id << "\n";
    } else {
        std::cout << "page " << page_id << " was not in tlb anyway \n";

    }
}

void TLB::clear() {
    entries_.clear();
    std::cout << "TLB flushed\n";
}

int TLB::find_lru_page() const {
    int oldest_page = -1;
    int min_ts = INT_MAX;

    for (const auto& [page_id, entry] : entries_) {
        if (entry.valid && entry.timestamp < min_ts) {
            min_ts = entry.timestamp;
            oldest_page = page_id;
        }
    }

    return oldest_page;
}


// ------ PageTable ------
PageTable::PageTable(size_t pages_count)
    : pages_count_(pages_count),
    entries_(pages_count),
    valid_count_(0)
{
    std::cout << "[PageTable] Initialisiere mit " << pages_count_ << " Seiten\n";
    for (size_t i = 0; i < pages_count_; ++i) {
        entries_[i] = { static_cast<int>(i), false, false, false };
    }
}

bool PageTable::is_valid_index(int page_id) const {
    return page_id >= 0 && static_cast<size_t>(page_id) < pages_count_;
}

bool PageTable::is_valid(int page_id) const {
    bool result = is_valid_index(page_id) && entries_[page_id].valid;
    std::cout << "[PageTable] is_valid(" << page_id << ") -> " << (result ? "true" : "false") << "\n";
    return result;
}

void PageTable::set_valid(int page_id) {
    if (is_valid_index(page_id)) {
        auto& e = entries_[page_id];

        if (!e.valid) {
            e.valid = true;
            ++valid_count_;
            std::cout << "[PageTable] Seite " << page_id << " wird gültig gemacht. valid_count_ = " << valid_count_ << "\n";
        } else {
            std::cout << "[PageTable] Seite " << page_id << " war bereits gültig\n";
        }

        e.referenced = true;
        e.modified   = false;
        std::cout << "[PageTable] Seite " << page_id << " gesetzt: referenced = true, modified = false\n";
    } else {
        std::cout << "[PageTable] set_valid: Ungültiger page_id " << page_id << "\n";
    }
}

void PageTable::invalidate(int page_id) {
    if (is_valid_index(page_id)) {
        auto& e = entries_[page_id];
        if (e.valid) {
            e.valid = false;
            --valid_count_;
            std::cout << "[PageTable] Seite " << page_id << " wird ungültig gemacht. valid_count_ = " << valid_count_ << "\n";
        } else {
            std::cout << "[PageTable] Seite " << page_id << " war bereits ungültig\n";
        }
    } else {
        std::cout << "[PageTable] invalidate: Ungültiger page_id " << page_id << "\n";
    }
}

size_t PageTable::size() const {
    std::cout << "[PageTable] size() -> " << valid_count_ << "\n";
    return valid_count_;
}

void PageTable::set_referenced(int page_id, bool v) {
    if (is_valid_index(page_id)) {
        entries_[page_id].referenced = v;
        std::cout << "[PageTable] Seite " << page_id << ": referenced = " << (v ? "true" : "false") << "\n";
    } else {
        std::cout << "[PageTable] set_referenced: Ungültiger page_id " << page_id << "\n";
    }
}



// ------ Process ------

Process::Process(int pid, size_t pages_count)
    : id_(pid),
    page_table_(pages_count)
{}

int Process::getID() const {
    return id_;
}

PageTable& Process::getPageTable() {
    return page_table_;
}

// ------ MMU (nur 1 Prozess) ------
void MMU::handle_event(const des::Event& e) {
    auto& pt = process_.getPageTable();

    // 0) Ungültige Seite?
    if (!pt.is_valid_index(e.page_id)) {
        std::cout << "virtual page with number " << e.page_id << " doesn't exist\n";
        return;
    }

    stats_.count_access();

    // 1) TLB-Hit
    if (tlb_.lookup(e.page_id)) {
        std::cout << "TLB hit page " << e.page_id << "\n";
        stats_.count_tlb_hit();
        pt.set_referenced(e.page_id, true);
        algo_.on_page_access(e.page_id);

        // Timestamp im TLB aktualisieren
        tlb_.update(e.page_id, e.timestamp);

        std::cout << "Event with timestamp " << e.timestamp << " processed\n";
        return;
    }

    // 2) Page-Table-Hit (TLB-Miss)
    if (pt.is_valid(e.page_id)) {
        std::cout << "Page table hit page " << e.page_id << "\n";
        pt.set_referenced(e.page_id, true);
        algo_.on_page_access(e.page_id);

        // Neuer TLB-Eintrag (evicted ggf. über LRU)
        tlb_.update(e.page_id, e.timestamp);

        std::cout << "Event with timestamp " << e.timestamp << " processed\n";
        return;
    }

    // 3) Page-Fault
    std::cout << "Page fault on page " << e.page_id << "\n";
    stats_.count_page_fault();

    // a) Speicher voll? → Page-Ersetzung
    if (pt.size() >= max_frames_) {
        int victim = algo_.select_victim();
        if (victim != -1) {
            std::cout << "Replacing page " << victim << "\n";

            // erst PageTable, dann TLB invalidieren
            pt.invalidate(victim);
            tlb_.invalidate(victim);
        }
    }

    // b) Neue Seite in den PageTable laden
    pt.set_valid(e.page_id);
    pt.set_referenced(e.page_id, true);

    // c) Algorithmus benachrichtigen
    algo_.on_page_fault(e.page_id);
    algo_.on_page_access(e.page_id);

    // d) Und jetzt endlich ins TLB
    tlb_.update(e.page_id, e.timestamp);

    std::cout << "Event with timestamp " << e.timestamp << " processed\n";
}


} // namespace sim
