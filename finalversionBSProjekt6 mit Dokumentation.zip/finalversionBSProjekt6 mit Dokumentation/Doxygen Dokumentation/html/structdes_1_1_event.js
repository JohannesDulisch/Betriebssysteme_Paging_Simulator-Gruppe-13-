var structdes_1_1_event =
[
    [ "page_id", "structdes_1_1_event.html#aa90c20716fca105c272236bee6c5a278", null ],
    [ "timestamp", "structdes_1_1_event.html#a68b88dc15d4839f71f4cbb5eaf10c563", null ],
    [ "type", "structdes_1_1_event.html#a0f146ccd3391bdfa4b2c2c098971b291", null ]
];