var dir_4fef79e7177ba769987a8da36c892c5f =
[
    [ "Desktop_Qt_6_7_3_MinGW_64_bit-Debug", "dir_17594bac5abdb43b7b633c954f50ef9e.html", "dir_17594bac5abdb43b7b633c954f50ef9e" ],
    [ "Desktop_Qt_6_9_0_MinGW_64_bit-Debug", "dir_19572e210953950637ab0e0bc42e961a.html", "dir_19572e210953950637ab0e0bc42e961a" ],
    [ "Qt_6_9_1_for_macOS-Debug", "dir_10be00835cdbea93804783aa0e31372b.html", "dir_10be00835cdbea93804783aa0e31372b" ]
];