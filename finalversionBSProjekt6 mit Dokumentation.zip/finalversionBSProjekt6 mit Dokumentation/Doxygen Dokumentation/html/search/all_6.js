var searchData=
[
  ['getid_0',['getID',['../classsim_1_1_process.html#ac097a71964b07158e3f0481b8b32d347',1,'sim::Process']]],
  ['getpagetable_1',['getPageTable',['../classsim_1_1_process.html#a9f9cf8d14c23a7382acdeb243aa9782f',1,'sim::Process']]]
];
