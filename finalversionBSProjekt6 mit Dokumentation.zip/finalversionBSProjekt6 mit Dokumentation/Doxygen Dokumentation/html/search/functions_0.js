var searchData=
[
  ['clear_0',['clear',['../classsim_1_1_t_l_b.html#a9d9fc3df35f85da97c363072a7ddcd69',1,'sim::TLB']]],
  ['count_5faccess_1',['count_access',['../classsim_1_1_statistics.html#a844d58aefdfe70cee18e4d9cb20d843f',1,'sim::Statistics']]],
  ['count_5fpage_5ffault_2',['count_page_fault',['../classsim_1_1_statistics.html#a659c9a8a5e7141b5dbe747e4c1bab009',1,'sim::Statistics']]],
  ['count_5ftlb_5fhit_3',['count_tlb_hit',['../classsim_1_1_statistics.html#ae182ab5151b476422bdd3fcb7dff0aef',1,'sim::Statistics']]],
  ['createqueue_5ffifo_4',['createQueue_FIFO',['../main_8cpp.html#abaca8fb4f3ce19392ddde751b3fad023',1,'main.cpp']]],
  ['createqueue_5fsecondchance_5',['createQueue_SecondChance',['../main_8cpp.html#a0e859723aa8ed801875d62ba78b5c1b4',1,'main.cpp']]]
];
