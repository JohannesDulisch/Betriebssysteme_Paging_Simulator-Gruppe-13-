var searchData=
[
  ['des_0',['des',['../namespacedes.html',1,'']]]
];
