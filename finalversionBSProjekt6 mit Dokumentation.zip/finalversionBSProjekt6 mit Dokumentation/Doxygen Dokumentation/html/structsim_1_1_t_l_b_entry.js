var structsim_1_1_t_l_b_entry =
[
    [ "page_id", "structsim_1_1_t_l_b_entry.html#ae9dc5e09cdb667cc414eb4f33702bde7", null ],
    [ "timestamp", "structsim_1_1_t_l_b_entry.html#a418a9b3d0d47b26333f923f76f9e497f", null ],
    [ "valid", "structsim_1_1_t_l_b_entry.html#a6dcd1fd2531913e291fddad1f2965b93", null ]
];