var structdes_1_1_compare_event =
[
    [ "operator()", "structdes_1_1_compare_event.html#aaf1b2dfd7c4830c95c5454250a01fbfa", null ]
];