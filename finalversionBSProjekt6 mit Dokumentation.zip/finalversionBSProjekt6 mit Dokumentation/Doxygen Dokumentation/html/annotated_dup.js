var annotated_dup =
[
    [ "des", "namespacedes.html", [
      [ "CompareEvent", "structdes_1_1_compare_event.html", "structdes_1_1_compare_event" ],
      [ "Event", "structdes_1_1_event.html", "structdes_1_1_event" ],
      [ "EventQueue", "classdes_1_1_event_queue.html", "classdes_1_1_event_queue" ]
    ] ],
    [ "sim", "namespacesim.html", [
      [ "MMU", "classsim_1_1_m_m_u.html", "classsim_1_1_m_m_u" ],
      [ "PageTable", "classsim_1_1_page_table.html", "classsim_1_1_page_table" ],
      [ "PageTableEntry", "structsim_1_1_page_table_entry.html", "structsim_1_1_page_table_entry" ],
      [ "Process", "classsim_1_1_process.html", "classsim_1_1_process" ],
      [ "Statistics", "classsim_1_1_statistics.html", "classsim_1_1_statistics" ],
      [ "TLB", "classsim_1_1_t_l_b.html", "classsim_1_1_t_l_b" ],
      [ "TLBEntry", "structsim_1_1_t_l_b_entry.html", "structsim_1_1_t_l_b_entry" ]
    ] ],
    [ "FIFOAlgorithm", "class_f_i_f_o_algorithm.html", "class_f_i_f_o_algorithm" ],
    [ "LRUAlgorithm", "class_l_r_u_algorithm.html", "class_l_r_u_algorithm" ],
    [ "NFUAgingAlgorithm", "class_n_f_u_aging_algorithm.html", "class_n_f_u_aging_algorithm" ],
    [ "NFUAlgorithm", "class_n_f_u_algorithm.html", "class_n_f_u_algorithm" ],
    [ "NRUAlgorithm", "class_n_r_u_algorithm.html", "class_n_r_u_algorithm" ],
    [ "PageTable", "class_page_table.html", "class_page_table" ],
    [ "PageTableEntry", "struct_page_table_entry.html", "struct_page_table_entry" ],
    [ "PagingAlgorithm", "class_paging_algorithm.html", "class_paging_algorithm" ],
    [ "SecondChanceAlgorithm", "class_second_chance_algorithm.html", "class_second_chance_algorithm" ]
];