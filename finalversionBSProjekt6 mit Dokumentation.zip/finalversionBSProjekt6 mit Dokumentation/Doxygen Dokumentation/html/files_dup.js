var files_dup =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ "algorithms.cpp", "algorithms_8cpp.html", "algorithms_8cpp" ],
    [ "algorithms.h", "algorithms_8h.html", "algorithms_8h" ],
    [ "discrete_event_simulation.h", "discrete__event__simulation_8h.html", "discrete__event__simulation_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "simulation.cpp", "simulation_8cpp.html", null ],
    [ "simulation.h", "simulation_8h.html", "simulation_8h" ]
];