/**
 * @file discrete_event_simulation.hpp
 * @brief Basisklassen für eine diskrete Ereignissimulation (DES).
 *
 * Diese Header-File definiert die Event-Struktur, die EventQueue
 * und grundlegende Funktionen zum Einreihen und Abarbeiten von Events.
 */

#ifndef DISCRETE_EVENT_SIMULATION_HPP
#define DISCRETE_EVENT_SIMULATION_HPP

#include <queue>
#include <vector>
#include <stdexcept>

namespace des {

/**
 * @enum EventType
 * @brief Typen von Events in der Simulation.
 */
enum class EventType {
    PAGE_ACCESS /**< Zugriff auf eine Seite */
};

/**
 * @struct Event
 * @brief Repräsentiert ein einzelnes Ereignis in der Simulation.
 */
struct Event {
    int       timestamp{}; /**< Zeitpunkt des Events */
    EventType type{};      /**< Art des Events */
    int       page_id{};   /**< Betroffene Seite */
};

/**
 * @struct CompareEvent
 * @brief Vergleichsoperator für Prioritätswarteschlange, sortiert nach timestamp.
 */
struct CompareEvent {
    /**
     * @brief Vergleich zweier Events für die Priority-Queue.
     * @param a Erstes Event
     * @param b Zweites Event
     * @return true, wenn a später als b liegt (a hat größere timestamp)
     */
    bool operator()(Event const& a, Event const& b) const noexcept {
        return a.timestamp > b.timestamp;
    }
};

/**
 * @class EventQueue
 * @brief Warteschlange für Events, sortiert nach Zeitpunkt.
 */
class EventQueue {
public:
    /**
     * @brief Neues Event einreihen (lvalue).
     * @param e Event, das eingereiht werden soll
     */
    void push(const Event& e) {
        events_.push(e);
    }

    /**
     * @brief Neues Event einreihen (rvalue, move).
     * @param e Event, das eingereiht werden soll
     */
    void push(Event&& e) {
        events_.push(std::move(e));
    }

    /**
     * @brief Prüfen, ob die Warteschlange leer ist.
     * @return true, wenn leer
     */
    bool empty() const noexcept {
        return events_.empty();
    }

    /**
     * @brief Anzahl der Events in der Warteschlange.
     * @return Größe der Warteschlange
     */
    std::size_t size() const noexcept {
        return events_.size();
    }

    /**
     * @brief Das nächste Event entnehmen.
     * @throw std::runtime_error, wenn die Queue leer ist
     * @return Entnommenes Event
     */
    Event pop() {
        if (empty()) {
            throw std::runtime_error("EventQueue::pop() called on empty queue");
        }
        Event e = std::move(const_cast<Event&>(events_.top())); // Move spart Kopie
        events_.pop();
        return e;
    }

    /**
     * @brief Ein Simulationsschritt: ein Event verarbeiten.
     * @tparam Handler Funktor oder Lambda, das ein Event verarbeitet
     * @param handler Handler für das Event
     */
    template<typename Handler>
    void step(Handler&& handler) {
        if (!empty()) {
            handler(pop());
        }
    }

    /**
     * @brief Alle Events abarbeiten, bis die Queue leer ist.
     * @tparam Handler Funktor oder Lambda, das ein Event verarbeitet
     * @param handler Handler für das Event
     */
    template<typename Handler>
    void run(Handler&& handler) {
        while (!empty()) {
            handler(pop());
        }
    }

private:
    std::priority_queue<Event, std::vector<Event>, CompareEvent> events_; /**< Prioritätswarteschlange */
};

} // namespace des

#endif // DISCRETE_EVENT_SIMULATION_HPP
