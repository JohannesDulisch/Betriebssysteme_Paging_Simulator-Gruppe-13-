/**
 * @file simulation.hpp
 * @brief Hauptkomponenten der Paging-Simulation: Prozesse, TLB, PageTable, MMU und Statistik.
 *
 * Diese File definiert:
 * - Statistik für die Simulation
 * - TLB und TLB-Einträge
 * - PageTable und Einträge
 * - Prozesse
 * - MMU zum Verarbeiten von Events
 */

#ifndef SIMULATION_HPP
#define SIMULATION_HPP

#include "discrete_event_simulation.h"
#include "algorithms.h"
#include <iostream>
#include <unordered_map>
#include <vector>

namespace sim {

/**
 * @class Statistics
 * @brief Hält Statistiken zur Paging-Simulation.
 */
class Statistics {
public:
    void count_access()     { ++page_accesses_; }    /**< Seitenzugriffe zählen */
    void count_tlb_hit()    { ++tlb_hits_; }         /**< TLB-Treffer zählen */
    void count_page_fault() { ++page_faults_; }      /**< Seitenfehler zählen */

    /**
     * @brief Statistik ausgeben.
     */
    void print() const {
        std::cout << "\n"
                  << "================ Statistik ================\n"
                  << "Seitenzugriffe: " << page_accesses_ << "\n"
                  << "TLB-Treffer:    " << tlb_hits_      << "\n"
                  << "Seitenfehler:   " << page_faults_   << "\n"
                  << "===========================================\n\n";
    }

private:
    int page_accesses_ = 0; /**< Zähler für Seitenzugriffe */
    int tlb_hits_      = 0; /**< Zähler für TLB-Treffer */
    int page_faults_   = 0; /**< Zähler für Seitenfehler */
};

/**
 * @struct TLBEntry
 * @brief Eintrag in der TLB.
 */
struct TLBEntry {
    int  page_id;   /**< ID der Seite */
    bool valid;     /**< Gültigkeitsbit */
    int  timestamp; /**< Zeitpunkt des letzten Zugriffs */
};

/**
 * @class TLB
 * @brief Translation Lookaside Buffer (schneller Cache für Seitenübersetzungen).
 */
class TLB {
public:
    /**
     * @brief Konstruktor.
     * @param max_size Maximale Anzahl der Einträge in der TLB
     */
    TLB(size_t max_size);

    /**
     * @brief Prüft, ob die Seite in der TLB ist.
     * @param page_id ID der Seite
     * @return true, falls gültig und vorhanden
     */
    bool lookup(int page_id);

    /**
     * @brief TLB-Eintrag aktualisieren oder hinzufügen.
     * @param page_id ID der Seite
     * @param timestamp Zeitpunkt des Zugriffs
     */
    void update(int page_id, int timestamp);

    /** Ungültig machen eines TLB-Eintrags */
    void invalidate(int page_id);

    /** Alle Einträge löschen */
    void clear();

private:
    size_t max_size_; /**< Maximale Anzahl der Einträge */
    std::unordered_map<int, TLBEntry> entries_; /**< TLB-Inhalte */

    /** Findet die LRU-Seite zum Entfernen */
    int find_lru_page() const;
};

/**
 * @struct PageTableEntry
 * @brief Eintrag in der Seitentabelle.
 */
struct PageTableEntry {
    int  page_id;     /**< ID der Seite */
    bool valid;       /**< Gültigkeitsbit */
    bool referenced;  /**< Referenzbit */
    bool modified;    /**< Änderungsbit */
};

/**
 * @class PageTable
 * @brief Verwaltung der Seitentabelle eines Prozesses.
 */
class PageTable {
public:
    /**
     * @brief Konstruktor.
     * @param pages_count Anzahl der Seiten
     */
    PageTable(size_t pages_count);

    bool is_valid(int page_id) const;         /**< Prüfen, ob Seite gültig */
    void set_valid(int page_id);              /**< Seite als gültig markieren */
    void invalidate(int page_id);             /**< Seite als ungültig markieren */
    size_t size() const;                      /**< Anzahl der Einträge */
    void set_referenced(int page_id, bool v); /**< Referenzbit setzen */
    const PageTableEntry& entry(size_t idx) const { return entries_[idx]; } /**< Zugriff auf Eintrag */
    size_t total_pages() const { return pages_count_; }                     /**< Gesamtanzahl der Seiten */
    bool is_valid_index(int page_id) const;                                  /**< Prüfen, ob Index gültig */

private:
    size_t pages_count_;                     /**< Gesamtanzahl Seiten */
    std::vector<PageTableEntry> entries_;    /**< Einträge der Seitentabelle */
    size_t valid_count_;                     /**< Anzahl gültiger Seiten */
};

/**
 * @class Process
 * @brief Repräsentiert einen Prozess mit eigener Seitentabelle.
 */
class Process {
public:
    /**
     * @brief Konstruktor.
     * @param pid Prozess-ID
     * @param pages_count Anzahl der Seiten
     */
    Process(int pid, size_t pages_count);

    int        getID() const;      /**< Prozess-ID zurückgeben */
    PageTable& getPageTable();      /**< Zugriff auf die Seitentabelle */

private:
    int       id_;         /**< Prozess-ID */
    PageTable page_table_; /**< Seitentabelle des Prozesses */
};

/**
 * @class MMU
 * @brief Memory Management Unit zum Verarbeiten von Events und Seitenübersetzung.
 */
class MMU {
public:
    /**
     * @brief Konstruktor.
     * @param tlb Referenz auf die TLB
     * @param algo Referenz auf den Seitenersetzungs-Algorithmus
     * @param stats Referenz auf Statistikobjekt
     * @param max_frames Maximale Anzahl physischer Frames
     * @param process Referenz auf den Prozess
     */
    MMU(TLB& tlb, PagingAlgorithm& algo, Statistics& stats, size_t max_frames, Process& process)
        : tlb_(tlb),
        algo_(algo),
        stats_(stats),
        max_frames_(max_frames),
        process_(process) {}

    /**
     * @brief Bearbeitet ein Event (z.B. Seitenzugriff).
     * @param e Event, das bearbeitet werden soll
     */
    void handle_event(const des::Event& e);

private:
    TLB&             tlb_;         /**< Referenz auf TLB */
    PagingAlgorithm& algo_;        /**< Referenz auf Algorithmus */
    Statistics&      stats_;       /**< Referenz auf Statistik */
    size_t           max_frames_;  /**< Maximale Frames im Speicher */
    Process&         process_;     /**< Referenz auf Prozess */
};

} // namespace sim

#endif // SIMULATION_HPP
