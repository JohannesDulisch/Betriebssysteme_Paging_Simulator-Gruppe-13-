#include "algorithms.h"
#include "simulation.h"

using sim::PageTable;
using sim::PageTableEntry;

/**
 * @brief Hilfsfunktion: Index einer Seite in der PageTable suchen.
 * @param pt Referenz auf die Seitentabelle
 * @param page_id ID der gesuchten Seite
 * @return Index der Seite oder -1, wenn nicht gefunden
 */
namespace {
size_t find_index_by_page_id(const PageTable& pt, int page_id) {
    for (size_t i = 0; i < pt.total_pages(); ++i) {
        const PageTableEntry& e = pt.entry(i);
        if (e.page_id == page_id) return i;
    }
    return static_cast<size_t>(-1);
}
}

// ================= NRU =================

/**
 * @brief Wählt eine Opferseite gemäß NRU (Not Recently Used) aus.
 *
 * Die Seiten werden nach ihrer Klasse sortiert:
 * Klasse = 0: nicht referenziert, nicht modifiziert
 * Klasse = 1: nicht referenziert, modifiziert
 * Klasse = 2: referenziert, nicht modifiziert
 * Klasse = 3: referenziert, modifiziert
 *
 * @return ID der zu entfernenden Seite
 */
int NRUAlgorithm::select_victim() {
    int victim_page = -1;
    int min_class = 4;

    for (size_t i = 0; i < pt_.total_pages(); ++i) {
        const PageTableEntry& e = pt_.entry(i);
        if (!e.valid) continue;
        int cls = (e.referenced ? 2 : 0) + (e.modified ? 1 : 0);
        if (cls < min_class) {
            min_class = cls;
            victim_page = e.page_id;
            if (min_class == 0) break; // frühzeitiger Abbruch für beste Klasse
        }
    }

    std::cout << "[NRU] Physischer Speicher voll -> entferne Seite "
              << victim_page << " (Klasse = " << min_class << ")\n";
    return victim_page;
}

// ============== Second Chance ==========

/**
 * @brief Wählt eine Opferseite gemäß Second-Chance-Algorithmus aus.
 *
 * Prüft die Seiten der Warteschlange in Uhrzeiger-Reihenfolge.
 * Seiten mit gesetztem Referenzbit erhalten eine zweite Chance.
 *
 * @return ID der zu entfernenden Seite
 */
int SecondChanceAlgorithm::select_victim() {
    if (queue_.empty()) return -1;
    hand_ %= queue_.size();

    while (true) {
        int page_id = queue_[hand_];
        size_t idx = find_index_by_page_id(pt_, page_id);

        bool referenced = false;
        if (idx != static_cast<size_t>(-1)) {
            referenced = pt_.entry(idx).referenced;
        }

        if (referenced) {
            pt_.set_referenced(page_id, false);  // Referenzbit zurücksetzen
            hand_ = (hand_ + 1) % queue_.size();
        } else {
            int victim = page_id;
            queue_.erase(queue_.begin() + static_cast<std::ptrdiff_t>(hand_));
            if (!queue_.empty()) hand_ %= queue_.size();

            std::cout << "[SecondChance] Physischer Speicher voll -> entferne Seite "
                      << victim << "\n";
            return victim;
        }
    }
}
