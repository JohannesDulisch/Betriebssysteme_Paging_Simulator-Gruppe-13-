var classsim_1_1_statistics =
[
    [ "count_access", "classsim_1_1_statistics.html#a844d58aefdfe70cee18e4d9cb20d843f", null ],
    [ "count_page_fault", "classsim_1_1_statistics.html#a659c9a8a5e7141b5dbe747e4c1bab009", null ],
    [ "count_tlb_hit", "classsim_1_1_statistics.html#ae182ab5151b476422bdd3fcb7dff0aef", null ],
    [ "print", "classsim_1_1_statistics.html#a67ac5d667421aa751faf1f359d5267cf", null ]
];