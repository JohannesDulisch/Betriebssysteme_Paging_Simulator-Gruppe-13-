var searchData=
[
  ['lookup_0',['lookup',['../classsim_1_1_t_l_b.html#a0cc87152c16e97d5a593ad2b823ae179',1,'sim::TLB']]],
  ['lrualgorithm_1',['LRUAlgorithm',['../class_l_r_u_algorithm.html',1,'LRUAlgorithm'],['../class_l_r_u_algorithm.html#a3bfc82ea0c44cd69b41c4d8356eeea40',1,'LRUAlgorithm::LRUAlgorithm()']]]
];
