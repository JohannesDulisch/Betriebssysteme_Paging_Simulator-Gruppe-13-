var searchData=
[
  ['clear_0',['clear',['../classsim_1_1_t_l_b.html#a9d9fc3df35f85da97c363072a7ddcd69',1,'sim::TLB']]],
  ['count_5faccess_1',['count_access',['../classsim_1_1_statistics.html#a844d58aefdfe70cee18e4d9cb20d843f',1,'sim::Statistics']]],
  ['count_5fpage_5ffault_2',['count_page_fault',['../classsim_1_1_statistics.html#a659c9a8a5e7141b5dbe747e4c1bab009',1,'sim::Statistics']]],
  ['count_5ftlb_5fhit_3',['count_tlb_hit',['../classsim_1_1_statistics.html#ae182ab5151b476422bdd3fcb7dff0aef',1,'sim::Statistics']]],
  ['createqueue_4',['createQueue',['../main_8cpp.html#a31a360545183243668fc0e9b0de95c84',1,'main.cpp']]]
];
