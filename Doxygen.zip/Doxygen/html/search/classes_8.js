var searchData=
[
  ['tlb_0',['TLB',['../classsim_1_1_t_l_b.html',1,'sim']]],
  ['tlbentry_1',['TLBEntry',['../structsim_1_1_t_l_b_entry.html',1,'sim']]]
];
