var searchData=
[
  ['tlb_0',['TLB',['../classsim_1_1_t_l_b.html#a030ba7027d656c71d62f205f3f1c234a',1,'sim::TLB']]],
  ['total_5fpages_1',['total_pages',['../classsim_1_1_page_table.html#ab5e191d2fecbf6e9ea447cc7f15c9158',1,'sim::PageTable::total_pages()'],['../class_page_table.html#ab5e191d2fecbf6e9ea447cc7f15c9158',1,'PageTable::total_pages()']]]
];
