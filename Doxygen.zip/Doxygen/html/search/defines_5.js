var searchData=
[
  ['platform_5fid_0',['PLATFORM_ID',['../_c_make_c_x_x_compiler_id_8cpp.html#adbc5372f40838899018fadbc89bd588b',1,'CMakeCXXCompilerId.cpp']]]
];
