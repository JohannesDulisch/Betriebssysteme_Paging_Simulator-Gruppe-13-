var searchData=
[
  ['getid_0',['getID',['../classsim_1_1_process.html#ac097a71964b07158e3f0481b8b32d347',1,'sim::Process']]],
  ['getname_1',['getName',['../class_paging_algorithm.html#a2ce9db95ebba49bc9774c582e4d54fd6',1,'PagingAlgorithm::getName()'],['../class_n_r_u_algorithm.html#a5dc0782ee509ae65c19bd2bbd6c03837',1,'NRUAlgorithm::getName()'],['../class_f_i_f_o_algorithm.html#aafd72584afa09985610f468a4a23a12c',1,'FIFOAlgorithm::getName()'],['../class_second_chance_algorithm.html#a0b40be80a7fc710d6d2ba6ed56ae7f08',1,'SecondChanceAlgorithm::getName()'],['../class_l_r_u_algorithm.html#a084cf560aa155e1410aed7eb842bba8e',1,'LRUAlgorithm::getName()'],['../class_n_f_u_algorithm.html#a6bc9cd982a3c9f4e5b5e838c5d853d50',1,'NFUAlgorithm::getName()'],['../class_n_f_u_aging_algorithm.html#a2b979a701abf757497b68c2f90b392c8',1,'NFUAgingAlgorithm::getName()']]],
  ['getpagetable_2',['getPageTable',['../classsim_1_1_process.html#a9f9cf8d14c23a7382acdeb243aa9782f',1,'sim::Process']]]
];
