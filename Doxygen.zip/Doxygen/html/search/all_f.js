var searchData=
[
  ['secondchancealgorithm_0',['SecondChanceAlgorithm',['../class_second_chance_algorithm.html',1,'SecondChanceAlgorithm'],['../class_second_chance_algorithm.html#ad1cf5aa25019b504eb60235cbfad5647',1,'SecondChanceAlgorithm::SecondChanceAlgorithm()']]],
  ['select_5fvictim_1',['select_victim',['../class_paging_algorithm.html#ae22ca79e08ea7763b436cf6fdb7388cc',1,'PagingAlgorithm::select_victim()'],['../class_n_r_u_algorithm.html#a0acb9adce5b2d408facc7f1b10a9f0a1',1,'NRUAlgorithm::select_victim()'],['../class_f_i_f_o_algorithm.html#a4f0f4cc797395386e8a190c5b41b66c6',1,'FIFOAlgorithm::select_victim()'],['../class_second_chance_algorithm.html#aa6b2064b3b7ad3e0f192e47ed8f0e718',1,'SecondChanceAlgorithm::select_victim()'],['../class_l_r_u_algorithm.html#aba1a0c76c68e707a2ca58b9162ee59c0',1,'LRUAlgorithm::select_victim()'],['../class_n_f_u_algorithm.html#a4b43d770d1f4f6a7040e8d79752ef18b',1,'NFUAlgorithm::select_victim()'],['../class_n_f_u_aging_algorithm.html#ac0138691002602f4476a7da3ad0cfdbd',1,'NFUAgingAlgorithm::select_victim()']]],
  ['set_5freferenced_2',['set_referenced',['../classsim_1_1_page_table.html#a5a8b0873e45f8aeb45eb245ef64f8113',1,'sim::PageTable::set_referenced()'],['../class_page_table.html#a5a8b0873e45f8aeb45eb245ef64f8113',1,'PageTable::set_referenced()']]],
  ['set_5fvalid_3',['set_valid',['../classsim_1_1_page_table.html#a2f19071d993fefb276c9baead3770d3e',1,'sim::PageTable::set_valid()'],['../class_page_table.html#a2f19071d993fefb276c9baead3770d3e',1,'PageTable::set_valid()']]],
  ['sim_4',['sim',['../namespacesim.html',1,'']]],
  ['simulation_2ecpp_5',['simulation.cpp',['../simulation_8cpp.html',1,'']]],
  ['simulation_2eh_6',['simulation.h',['../simulation_8h.html',1,'']]],
  ['size_7',['size',['../classdes_1_1_event_queue.html#a9a4e031972551050a7175036c61dce0d',1,'des::EventQueue::size()'],['../classsim_1_1_page_table.html#a7de7c3398bfb1ed522412d0952ef605f',1,'sim::PageTable::size()'],['../class_page_table.html#a7de7c3398bfb1ed522412d0952ef605f',1,'PageTable::size()']]],
  ['statistics_8',['Statistics',['../classsim_1_1_statistics.html',1,'sim']]],
  ['step_9',['step',['../classdes_1_1_event_queue.html#a0e239ce9710b1ca398dc31aab1b41b0d',1,'des::EventQueue']]],
  ['stringify_10',['STRINGIFY',['../_c_make_c_x_x_compiler_id_8cpp.html#a43e1cad902b6477bec893cb6430bd6c8',1,'CMakeCXXCompilerId.cpp']]],
  ['stringify_5fhelper_11',['STRINGIFY_HELPER',['../_c_make_c_x_x_compiler_id_8cpp.html#a2ae9b72bb13abaabfcf2ee0ba7d3fa1d',1,'CMakeCXXCompilerId.cpp']]]
];
