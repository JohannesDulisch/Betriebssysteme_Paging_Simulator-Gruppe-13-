var class_l_r_u_algorithm =
[
    [ "LRUAlgorithm", "class_l_r_u_algorithm.html#a3bfc82ea0c44cd69b41c4d8356eeea40", null ],
    [ "getName", "class_l_r_u_algorithm.html#a084cf560aa155e1410aed7eb842bba8e", null ],
    [ "on_page_access", "class_l_r_u_algorithm.html#abe5820b756319ebb3f1a6003d1076fc1", null ],
    [ "on_page_fault", "class_l_r_u_algorithm.html#ab8138e8f394370b956148a9d2be217e6", null ],
    [ "select_victim", "class_l_r_u_algorithm.html#aba1a0c76c68e707a2ca58b9162ee59c0", null ]
];