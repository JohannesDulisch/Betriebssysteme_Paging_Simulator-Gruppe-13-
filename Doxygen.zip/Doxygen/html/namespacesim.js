var namespacesim =
[
    [ "MMU", "classsim_1_1_m_m_u.html", "classsim_1_1_m_m_u" ],
    [ "PageTable", "classsim_1_1_page_table.html", "classsim_1_1_page_table" ],
    [ "PageTableEntry", "structsim_1_1_page_table_entry.html", "structsim_1_1_page_table_entry" ],
    [ "Process", "classsim_1_1_process.html", "classsim_1_1_process" ],
    [ "Statistics", "classsim_1_1_statistics.html", "classsim_1_1_statistics" ],
    [ "TLB", "classsim_1_1_t_l_b.html", "classsim_1_1_t_l_b" ],
    [ "TLBEntry", "structsim_1_1_t_l_b_entry.html", "structsim_1_1_t_l_b_entry" ]
];