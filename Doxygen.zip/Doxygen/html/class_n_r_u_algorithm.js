var class_n_r_u_algorithm =
[
    [ "NRUAlgorithm", "class_n_r_u_algorithm.html#a97adda9f52cce2a6637d19471cff9669", null ],
    [ "getName", "class_n_r_u_algorithm.html#a5dc0782ee509ae65c19bd2bbd6c03837", null ],
    [ "on_page_access", "class_n_r_u_algorithm.html#afef0209654a53a4dcdaa59e445e87c55", null ],
    [ "on_page_fault", "class_n_r_u_algorithm.html#aaa778eb3c0d4465da81cb258304d440f", null ],
    [ "select_victim", "class_n_r_u_algorithm.html#a0acb9adce5b2d408facc7f1b10a9f0a1", null ]
];