var class_page_table =
[
    [ "PageTable", "class_page_table.html#a53049b0012a28f8e593bd1eec946999e", null ],
    [ "entry", "class_page_table.html#ae647b1d870a7daad064d63625be791dc", null ],
    [ "invalidate", "class_page_table.html#a49e6febe83b0a6a96d166bae8b540d84", null ],
    [ "is_valid", "class_page_table.html#a340be48a7f550a0a16e55d00cf1c6f69", null ],
    [ "is_valid_index", "class_page_table.html#a4b81faec5389dceb4b65e38f0f9acb84", null ],
    [ "set_referenced", "class_page_table.html#a5a8b0873e45f8aeb45eb245ef64f8113", null ],
    [ "set_valid", "class_page_table.html#a2f19071d993fefb276c9baead3770d3e", null ],
    [ "size", "class_page_table.html#a7de7c3398bfb1ed522412d0952ef605f", null ],
    [ "total_pages", "class_page_table.html#ab5e191d2fecbf6e9ea447cc7f15c9158", null ]
];