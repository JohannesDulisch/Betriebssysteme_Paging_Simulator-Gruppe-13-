var class_n_f_u_algorithm =
[
    [ "NFUAlgorithm", "class_n_f_u_algorithm.html#a43500e7f22de179cadd410f5c55906e1", null ],
    [ "getName", "class_n_f_u_algorithm.html#a6bc9cd982a3c9f4e5b5e838c5d853d50", null ],
    [ "on_page_access", "class_n_f_u_algorithm.html#aa9add132c218799726ef1439775d5735", null ],
    [ "on_page_fault", "class_n_f_u_algorithm.html#ae3b8183255a1001058fa186024659940", null ],
    [ "select_victim", "class_n_f_u_algorithm.html#a4b43d770d1f4f6a7040e8d79752ef18b", null ]
];