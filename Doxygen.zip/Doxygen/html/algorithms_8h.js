var algorithms_8h =
[
    [ "PagingAlgorithm", "class_paging_algorithm.html", "class_paging_algorithm" ],
    [ "NRUAlgorithm", "class_n_r_u_algorithm.html", "class_n_r_u_algorithm" ],
    [ "FIFOAlgorithm", "class_f_i_f_o_algorithm.html", "class_f_i_f_o_algorithm" ],
    [ "SecondChanceAlgorithm", "class_second_chance_algorithm.html", "class_second_chance_algorithm" ],
    [ "LRUAlgorithm", "class_l_r_u_algorithm.html", "class_l_r_u_algorithm" ],
    [ "NFUAlgorithm", "class_n_f_u_algorithm.html", "class_n_f_u_algorithm" ],
    [ "NFUAgingAlgorithm", "class_n_f_u_aging_algorithm.html", "class_n_f_u_aging_algorithm" ]
];