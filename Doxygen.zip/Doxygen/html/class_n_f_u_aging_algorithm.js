var class_n_f_u_aging_algorithm =
[
    [ "NFUAgingAlgorithm", "class_n_f_u_aging_algorithm.html#adcac7d8f7746631268e1f15b4c97d8d1", null ],
    [ "getName", "class_n_f_u_aging_algorithm.html#a2b979a701abf757497b68c2f90b392c8", null ],
    [ "on_page_access", "class_n_f_u_aging_algorithm.html#aaf355d1d3a32e630b3ef5a4cce22ce5b", null ],
    [ "on_page_fault", "class_n_f_u_aging_algorithm.html#af5ce08f3b2a3371df190e68ed57d2413", null ],
    [ "select_victim", "class_n_f_u_aging_algorithm.html#ac0138691002602f4476a7da3ad0cfdbd", null ]
];