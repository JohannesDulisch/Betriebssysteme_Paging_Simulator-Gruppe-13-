var class_second_chance_algorithm =
[
    [ "SecondChanceAlgorithm", "class_second_chance_algorithm.html#ad1cf5aa25019b504eb60235cbfad5647", null ],
    [ "getName", "class_second_chance_algorithm.html#a0b40be80a7fc710d6d2ba6ed56ae7f08", null ],
    [ "on_page_access", "class_second_chance_algorithm.html#a00b9903c879521ccfe01c2687dd1d5f3", null ],
    [ "on_page_fault", "class_second_chance_algorithm.html#a08e91df9880b19f49f021fa1f631f8a4", null ],
    [ "select_victim", "class_second_chance_algorithm.html#aa6b2064b3b7ad3e0f192e47ed8f0e718", null ]
];