#include "simulation.h"

namespace sim {

// ------ TLB ------

TLB::TLB(size_t max_size)
    : max_size_(max_size)
{}

bool TLB::lookup(int page_id) {
    auto it = entries_.find(page_id);
    return it != entries_.end() && it->second.valid;
}

void TLB::update(int page_id, int timestamp) {
    if (entries_.count(page_id)) {
        entries_[page_id] = {page_id, true, timestamp};
        return;
    }
    if (entries_.size() >= max_size_) {
        int victim = order_.front();
        order_.erase(order_.begin());
        entries_.erase(victim);
        std::cout << "TLB full -> evicting page " << victim << "\n";
    }
    entries_[page_id] = {page_id, true, timestamp};
    order_.push_back(page_id);
}


void TLB::clear() {
    entries_.clear();
    order_.clear();
    std::cout << "TLB flushed\n";
}


// ------ PageTable ------

PageTable::PageTable(size_t pages_count)
    : pages_count_(pages_count),
    entries_(pages_count),
    valid_count_(0)
{
    for (size_t i = 0; i < pages_count_; ++i) {
        entries_[i] = { static_cast<int>(i), false, false, false };
    }
}

bool PageTable::is_valid(int page_id) const {
    return page_id >= 0
           && static_cast<size_t>(page_id) < pages_count_
           && entries_[page_id].valid;
}

void PageTable::set_valid(int page_id) {
    if (page_id >= 0 && static_cast<size_t>(page_id) < pages_count_) {
        auto& e = entries_[page_id];
        if (!e.valid) {
            e.valid = true;
            ++valid_count_;
        }
        e.referenced = true;
        e.modified   = false;
    }
}

void PageTable::invalidate(int page_id) {
    if (page_id >= 0 && static_cast<size_t>(page_id) < pages_count_) {
        auto& e = entries_[page_id];
        if (e.valid) {
            e.valid = false;
            --valid_count_;
        }
    }
}

size_t PageTable::size() const {
    return valid_count_;
}

void PageTable::set_referenced(int page_id, bool v) {
    if (page_id >= 0 && static_cast<size_t>(page_id) < pages_count_) {
        entries_[page_id].referenced = v;
    }
}

// ------ Process ------

Process::Process(int pid, size_t pages_count)
    : id_(pid),
    page_table_(pages_count)
{}

int Process::getID() const {
    return id_;
}

PageTable& Process::getPageTable() {
    return page_table_;
}

// ------ MMU ------

MMU::MMU(TLB& tlb, PagingAlgorithm& algo, Statistics& stats, size_t max_frames)
    : tlb_(tlb),
    algo_(algo),
    stats_(stats),
    max_frames_(max_frames),
    current_process_(nullptr)
{}

void MMU::registerProcess(Process& p) {
    processes_[p.getID()] = &p;
    current_process_      = &p;
    std::cout << "Registered Process " << p.getID() << "\n";
}

int MMU::getCurrentPID() const {
    return current_process_ ? current_process_->getID() : -1;
}

void MMU::handle_event(const des::Event& e) {
    // ggf. Prozess-Wechsel
    auto it = processes_.find(e.process_id);
    if (it != processes_.end() && it->second->getID() != getCurrentPID()) {
        current_process_ = it->second;
        std::cout << "Switched to Process " << getCurrentPID() << "\n";

        // TLB nach Prozesswechsel zurücksetzen
        tlb_.clear();
    }

    stats_.count_access();
    auto& pt = current_process_->getPageTable();

    if (tlb_.lookup(e.page_id)) {
        std::cout << "[P" << getCurrentPID()
        << "] TLB hit page " << e.page_id << "\n";
        stats_.count_tlb_hit();
        pt.set_referenced(e.page_id, true);
        tlb_.update(e.page_id, e.timestamp);
        return;
    }

    if (pt.is_valid(e.page_id)) {
        std::cout << "[P" << getCurrentPID()
        << "] Page table hit page " << e.page_id << "\n";
        pt.set_referenced(e.page_id, true);
        tlb_.update(e.page_id, e.timestamp);
        return;
    }

    std::cout << "[P" << getCurrentPID()
              << "] Page fault on page " << e.page_id << "\n";
    stats_.count_page_fault();
    algo_.on_page_fault(e.page_id);

    if (pt.size() >= max_frames_) {
        int victim = algo_.select_victim();
        std::cout << "[P" << getCurrentPID()
                  << "] Replacing page " << victim << "\n";
        pt.set_referenced(victim, false);
        pt.invalidate(victim);
    }

    pt.set_valid(e.page_id);
    pt.set_referenced(e.page_id, true);
    tlb_.update(e.page_id, e.timestamp);
}

} // namespace sim
