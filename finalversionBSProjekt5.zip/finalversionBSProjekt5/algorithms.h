#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <vector>
#include <unordered_map>
#include <climits>

// Paging-Algorithmus Interface und Implementierungen
class PagingAlgorithm {
public:
    virtual void on_page_access(int page_id) = 0;
    virtual void on_page_fault(int page_id)  = 0;
    virtual int  select_victim()             = 0;
    virtual ~PagingAlgorithm() = default;
};


//Not Recently Used, First In First Out, Second Chance, Least Recently Used, Not Frequently Used (mit und Ohne Aging)



// NRU-Algorithmus
class NRUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override {
        referenced_[page_id] = true;
    }
    void on_page_fault(int page_id) override {
        referenced_[page_id] = true;
        modified_[page_id]   = false;
    }
    int select_victim() override {
        for (int cls = 0; cls < 4; ++cls) {
            for (auto& [page, _] : referenced_) {
                bool r = referenced_[page];
                bool m = modified_[page];
                if (((r ? 2 : 0) + (m ? 1 : 0)) == cls) {
                    referenced_.erase(page);
                    modified_.erase(page);
                    return page;
                }
            }
        }
        return referenced_.begin()->first;
    }

private:
    std::unordered_map<int, bool> referenced_;
    std::unordered_map<int, bool> modified_;
};






// FIFO-Algorithmus
class FIFOAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int) override {}
    void on_page_fault(int page_id) override {
        queue_.push_back(page_id);
    }
    int select_victim() override {
        int victim = queue_.front();
        queue_.erase(queue_.begin());
        return victim;
    }

private:
    std::vector<int> queue_;
};



// Second-Chance-Algorithmus
class SecondChanceAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override {
        referenced_[page_id] = true;
    }
    void on_page_fault(int page_id) override {
        queue_.push_back(page_id);
        referenced_[page_id] = true;
    }
    int select_victim() override {
        while (true) {
            int candidate = queue_[hand_];
            if (!referenced_[candidate]) {
                queue_.erase(queue_.begin() + hand_);
                referenced_.erase(candidate);
                return candidate;
            }
            referenced_[candidate] = false;
            hand_ = (hand_ + 1) % queue_.size();
        }
    }

private:
    std::vector<int>                  queue_;
    std::unordered_map<int, bool>     referenced_;
    size_t                            hand_ = 0;
};

// LRU-Algorithmus
class LRUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override {
        timestamps_[page_id] = ++time_;
    }
    void on_page_fault(int page_id) override {
        timestamps_[page_id] = ++time_;
    }
    int select_victim() override {
        int oldest = -1;
        int min_ts = INT_MAX;
        for (auto& [page, ts] : timestamps_) {
            if (ts < min_ts) {
                min_ts = ts;
                oldest = page;
            }
        }
        timestamps_.erase(oldest);
        return oldest;
    }

private:
    std::unordered_map<int, int> timestamps_;
    int                           time_ = 0;
};




class NFUAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override {
        frequency[page_id]++;
    }

    void on_page_fault(int page_id) override {
        frequency[page_id] = 1;
    }

    int select_victim() override {
        int min_freq = INT_MAX;
        int victim = -1;
        for (const auto& [page, freq] : frequency) {
            if (freq < min_freq) {
                min_freq = freq;
                victim = page;
            }
        }
        frequency.erase(victim);
        return victim;
    }

private:
    std::unordered_map<int, int> frequency;
};




class NFUAgingAlgorithm : public PagingAlgorithm {
public:
    void on_page_access(int page_id) override {
        referenced[page_id] = true;
    }

    void on_page_fault(int page_id) override {
        aging[page_id] = 0;
        referenced[page_id] = true;
    }

    int select_victim() override {
        for (auto& [page, age] : aging) {
            age >>= 1;
            if (referenced[page]) {
                age |= 0x80; // Set MSB
                referenced[page] = false;
            }
        }

        int victim = -1;
        int min_age = INT_MAX;
        for (const auto& [page, age] : aging) {
            if (age < min_age) {
                min_age = age;
                victim = page;
            }
        }

        aging.erase(victim);
        referenced.erase(victim);
        return victim;
    }

private:
    std::unordered_map<int, int> aging;
    std::unordered_map<int, bool> referenced;
};







#endif // ALGORITHMS_H
