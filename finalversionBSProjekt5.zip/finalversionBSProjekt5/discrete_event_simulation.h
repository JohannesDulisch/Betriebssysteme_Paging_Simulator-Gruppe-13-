#ifndef DISCRETE_EVENT_SIMULATION_HPP
#define DISCRETE_EVENT_SIMULATION_HPP

#include <queue>
#include <vector>
#include <functional>

namespace des {

// Typ von Ereignissen
enum class EventType { PAGE_ACCESS };

// Event-Datenstruktur
struct Event {
    int       timestamp;
    EventType type;
    int       page_id;
    int       process_id;
};

// Vergleich für Prioritätswarteschlange (kleiner Timestamp → höhere Priorität)
struct CompareEvent {
    bool operator()(Event const& a, Event const& b) const {
        return a.timestamp > b.timestamp;
    }
};

// Discrete-Event-Simulator (Ereignis-Warteschlange)
class EventQueue {
public:
    // Neues Event einreihen
    void push(Event const& e) {
        events_.push(e);
    }

    // Prüfen, ob noch Events übrig sind
    bool empty() const {
        return events_.empty();
    }

    // Ein Event herausnehmen
    Event pop() {
        Event e = events_.top();
        events_.pop();
        return e;
    }

    // Einen Schritt ausführen (Callback bekommt das Event)
    template<typename Handler>
    void step(Handler&& handler) {
        if (!empty()) {
            handler(pop());
        }
    }

    // Alle verbleibenden Events abarbeiten
    template<typename Handler>
    void run(Handler&& handler) {
        while (!empty()) {
            handler(pop());
        }
    }

private:
    std::priority_queue<Event, std::vector<Event>, CompareEvent> events_;
};

} // namespace des

#endif // DISCRETE_EVENT_SIMULATION_HPP
