#include "discrete_event_simulation.h"
#include "simulation.h"
#include "algorithms.h"
#include <memory>

int main() {
    using namespace des;
    using namespace sim;

    // Konfigurierbare Parameter
    size_t tlb_size    = 2;
    size_t frame_count = 3;

    // Discrete Event Simulator
    EventQueue               queue;
    TLB                       tlb(tlb_size);
    auto                      algo  = std::make_unique<NRUAlgorithm>();
    Statistics                stats;
    MMU                       mmu(tlb, *algo, stats, frame_count);

    // Prozesse anlegen und registrieren
    Process proc1(1, 5), proc2(2, 8);
    mmu.registerProcess(proc1);
    mmu.registerProcess(proc2);

    // Ereignisse einplanen
    queue.push({ 0, EventType::PAGE_ACCESS, 1, 1});
    queue.push({ 1, EventType::PAGE_ACCESS, 2, 1});
    queue.push({ 2, EventType::PAGE_ACCESS, 3, 1});
    queue.push({ 3, EventType::PAGE_ACCESS, 4, 1});
    queue.push({ 4, EventType::PAGE_ACCESS, 1, 1});
    queue.push({ 5, EventType::PAGE_ACCESS, 5, 1});
    queue.push({ 6, EventType::PAGE_ACCESS, 1, 1});
    queue.push({ 7, EventType::PAGE_ACCESS, 2, 1});
    queue.push({ 8, EventType::PAGE_ACCESS, 6, 1});
    queue.push({ 9, EventType::PAGE_ACCESS, 3, 1});
    queue.push({10, EventType::PAGE_ACCESS, 7, 1});
    queue.push({11, EventType::PAGE_ACCESS, 4, 1});

    queue.push({12, EventType::PAGE_ACCESS, 1, 2});
    queue.push({13, EventType::PAGE_ACCESS, 2, 2});
    queue.push({14, EventType::PAGE_ACCESS, 3, 2});
    queue.push({15, EventType::PAGE_ACCESS, 4, 2});
    queue.push({16, EventType::PAGE_ACCESS, 1, 2});
    queue.push({17, EventType::PAGE_ACCESS, 5, 2});
    queue.push({18, EventType::PAGE_ACCESS, 2, 2});
    queue.push({19, EventType::PAGE_ACCESS, 6, 2});
    queue.push({20, EventType::PAGE_ACCESS, 3, 2});
    queue.push({21, EventType::PAGE_ACCESS, 7, 2});
    queue.push({22, EventType::PAGE_ACCESS, 1, 2});
    queue.push({23, EventType::PAGE_ACCESS, 5, 2});

    // Simulation ausführen
    queue.run([&](Event const& e) {
        std::cout << "---------------------------\n";
        mmu.handle_event(e);
    });

    // Statistik ausgeben
    stats.print();
    return 0;
}
