#include "TLBEntry.h"

TLBEntry::TLBEntry(unsigned int page, unsigned int frame, bool isValid)
    : pageNumber(page), frameNumber(frame), valid(isValid) {}
