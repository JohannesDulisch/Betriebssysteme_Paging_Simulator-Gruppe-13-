#ifndef PAGETABLEENTRY_H
#define PAGETABLEENTRY_H

class PageTableEntry {
public:
    unsigned int pageFrameIndex;
    unsigned char frameAttributes;

    PageTableEntry(unsigned int frameIndex = 0);
};

#endif // PAGETABLEENTRY_H
