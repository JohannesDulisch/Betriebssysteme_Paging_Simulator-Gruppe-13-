#include "TLB.h"

TLB::TLB(unsigned int size) : entries(size), nextReplaceIndex(0) {}

TLBEntry* TLB::lookup(unsigned int pageNumber) {
    for (auto& entry : entries) {
        if (entry.valid && entry.pageNumber == pageNumber)
            return &entry;
    }
    return nullptr;
}

void TLB::insert(unsigned int pageNumber, unsigned int frameNumber) {
    entries[nextReplaceIndex] = TLBEntry(pageNumber, frameNumber, true);
    nextReplaceIndex = (nextReplaceIndex + 1) % entries.size();
}
