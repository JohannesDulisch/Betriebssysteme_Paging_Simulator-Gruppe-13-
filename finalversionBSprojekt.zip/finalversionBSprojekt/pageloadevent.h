#ifndef PAGELOADEVENT_H
#define PAGELOADEVENT_H

#include "Event.h"

class PageLoadEvent : public Event {
public:
    PageLoadEvent(int pageNumber, int timestamp);
};

#endif // PAGELOADEVENT_H
