#pragma once
#include "PageReplacementStrategy.h"

// Least Recently Used (LRU):
// Die Seite, die am längsten nicht verwendet wurde, wird ersetzt.
// Benötigt Zugriffshistorie oder Zeitstempel.
// Gute Trefferquote, aber aufwendig in der Umsetzung.

class LRUReplacement : public PageReplacementStrategy {
public:
    void replacePage(ED209& memoryManager, int newPage) override;
};
