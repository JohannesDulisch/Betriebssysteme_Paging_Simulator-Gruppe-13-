#include "PageReplacementStrategy.h"

// Keine Implementierung nötig, da alle Methoden abstrakt sind
