#pragma once
#include "PageReplacementStrategy.h"

// Not Recently Used (NRU):
// Seiten werden in Klassen eingeteilt basierend auf Referenz- und Modified-Bits.
// Klasse 0: nicht referenziert, nicht modifiziert → bevorzugt ersetzt
// Klasse 1: nicht referenziert, modifiziert
// Klasse 2: referenziert, nicht modifiziert
// Klasse 3: referenziert, modifiziert
// Periodisch werden Referenzbits zurückgesetzt.

class NotRecentlyUsedReplacement : public PageReplacementStrategy {
public:
    void replacePage(ED209& memoryManager, int newPage) override;
};
