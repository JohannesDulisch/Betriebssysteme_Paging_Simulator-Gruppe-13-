#pragma once
#include "PageReplacementStrategy.h"

// Second Chance (Clock):
// Erweiterung von FIFO mit Referenzbit.
// Wenn eine Seite ersetzt werden soll, wird ihr Referenzbit geprüft:
// - Wenn 1 → Bit auf 0 setzen und weiterdrehen
// - Wenn 0 → Seite wird ersetzt
// Der "Uhrzeiger" rotiert durch die Frames.

class SecondChanceReplacement : public PageReplacementStrategy {
public:
    void replacePage(ED209& memoryManager, int newPage) override;
};
