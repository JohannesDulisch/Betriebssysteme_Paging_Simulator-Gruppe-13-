#include "notrecentlyusedreplacement.h"

NotRecentlyUsedReplacement::NotRecentlyUsedReplacement() {}
