#ifndef MMU_H
#define MMU_H

#include "TLB.h"
#include "PageTable.h"

class MMU {
public:
    MMU(unsigned int tlbSize);
    unsigned int translate(unsigned int pageNumber, PageTable* pageTable);

private:
    TLB tlb;
};

#endif // MMU_H
