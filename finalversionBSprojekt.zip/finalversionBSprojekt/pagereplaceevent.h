#ifndef PAGEREPLACEEVENT_H
#define PAGEREPLACEEVENT_H

#include "Event.h"

class PageReplaceEvent : public Event {
public:
    PageReplaceEvent(int oldPage, int newPage, int timestamp);
};

#endif // PAGEREPLACEEVENT_H
