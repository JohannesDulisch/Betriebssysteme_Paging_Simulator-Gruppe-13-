#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include "Config.h"
#include "ED209.h"
#include "eventqueue.h"


#include "EventQueue.h"
#include "PageAccessEvent.h"
#include "PageFaultEvent.h"
#include "PageReplaceEvent.h"
#include "PageLoadEvent.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //größen von mmu, tlb, frames festlegen (im cofig.h)

    //hier structs anlegen

        ED209 system(TLB_SIZE);
        unsigned int pid = 1;
        system.addProcess(pid, NUM_PAGES, NUM_PAGE_FRAMES);

        system.accessMemory(1,1);


    //hier eventqueue anlegen
        int page_accesses[] = {
            0, 1, 2, 3, 4, 5, 6, 7,   // Füllen den Speicher
            0, 1, 2, 3,               // Wiederholungen (LRU/Clock merken sich das)
            8, 9,                    // Ersetzen nötig
            0, 1,                    // Wiederholung: LRU/Clock behalten sie, FIFO wirft sie evtl. raus
            10, 11, 12,              // Weitere Ersetzungen
            2, 3,                    // Wiederholung: LRU/Clock behalten sie, FIFO evtl. nicht
            13, 14, 15               // Noch mehr Ersetzungen
        };



    EventQueue queue;

        queue.AddEvent(PageAccessEvent(page_accesses[0]));












    //hier events anlegen

    //hier events in queue einfügen, in sinnvoller reihenfolge

    //hier seitenersetzungsalgo auswählen


    //die knöpfe mit der queue verbinden

    //if queue empty -> statistik anlegen



}

MainWindow::~MainWindow()
{
    delete ui;
}
