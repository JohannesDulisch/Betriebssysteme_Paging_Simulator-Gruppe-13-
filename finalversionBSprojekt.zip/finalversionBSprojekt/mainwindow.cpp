#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include "Config.h"
#include "ED209.h"
#include "eventqueue.h"


#include "EventQueue.h"
#include "PageAccessEvent.h"
#include "PageFaultEvent.h"
#include "PageReplaceEvent.h"
#include "PageLoadEvent.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //größen von mmu, tlb, frames festlegen (im cofig.h)

    //hier structs anlegen

        ED209 system(TLB_SIZE);
        unsigned int pid = 1;
        system.addProcess(pid, NUM_PAGES, NUM_PAGE_FRAMES);


    //hier eventqueue anlegen

    EventQueue queue;

        // Szenario: Speicher hat Platz für 2 Seiten, FIFO-Strategie angenommen

        // Prozess 1 greift auf Seite 5 → nicht im Speicher → Page Fault → Seite laden
        queue.AddEvent(new PageAccessEvent(0, 1, 5));
        queue.AddEvent(new PageFaultEvent(0, 1, 5));
        queue.AddEvent(new PageLoadEvent(1, 5));

        // Prozess 2 greift auf Seite 2 → nicht im Speicher → Page Fault → Seite laden
        queue.AddEvent(new PageAccessEvent(3, 2, 2));
        queue.AddEvent(new PageFaultEvent(3, 2, 2));
        queue.AddEvent(new PageLoadEvent(4, 2));

        // Prozess 1 greift erneut auf Seite 5 → Seite ist im Speicher → kein Fehler
        queue.AddEvent(new PageAccessEvent(6, 1, 5));

        // Prozess 3 greift auf Seite 7 → Speicher voll → Seite 2 wird ersetzt → Seite 7 laden
        queue.AddEvent(new PageAccessEvent(8, 3, 7));
        queue.AddEvent(new PageFaultEvent(8, 3, 7));
        queue.AddEvent(new PageReplaceEvent(9, 2, 7));
        queue.AddEvent(new PageLoadEvent(10, 7));

        // Prozess 2 greift wieder auf Seite 2 → Seite wurde ersetzt → Page Fault → Seite 5 wird ersetzt
        queue.AddEvent(new PageAccessEvent(12, 2, 2));
        queue.AddEvent(new PageFaultEvent(12, 2, 2));
        queue.AddEvent(new PageReplaceEvent(13, 5, 2));
        queue.AddEvent(new PageLoadEvent(14, 2));

        // Simulation starten
        queue.run();














    //hier events anlegen

    //hier events in queue einfügen, in sinnvoller reihenfolge

    //hier seitenersetzungsalgo auswählen


    //die knöpfe mit der queue verbinden

    //if queue empty -> statistik anlegen



}

MainWindow::~MainWindow()
{
    delete ui;
}
