#include "MMU.h"

MMU::MMU(unsigned int tlbSize) : tlb(tlbSize) {}

unsigned int MMU::translate(unsigned int pageNumber, PageTable* pageTable) {
    TLBEntry* entry = tlb.lookup(pageNumber);
    if (entry)

    //todo: flags setzen

        return entry->frameNumber; //im tlb

    PageTableEntry* pte = pageTable->getEntry(pageNumber);
    if (pte) {

        //todo: flags setzen

        tlb.insert(pageNumber, pte->pageFrameIndex);
        return pte->pageFrameIndex; //nicht im tlb, aber im speicher
    }

    return -1; // Fehler: Seite nicht vorhanden
}
