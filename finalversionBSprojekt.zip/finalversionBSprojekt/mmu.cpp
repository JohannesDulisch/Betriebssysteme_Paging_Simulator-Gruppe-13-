#include "MMU.h"

MMU::MMU(unsigned int tlbSize) : tlb(tlbSize) {}

unsigned int MMU::translate(unsigned int pageNumber, PageTable* pageTable) {
    TLBEntry* entry = tlb.lookup(pageNumber);
    if (entry)
        return entry->frameNumber;

    PageTableEntry* pte = pageTable->getEntry(pageNumber);
    if (pte) {
        tlb.insert(pageNumber, pte->pageFrameIndex);
        return pte->pageFrameIndex;
    }

    return -1; // Fehler: Seite nicht vorhanden
}
