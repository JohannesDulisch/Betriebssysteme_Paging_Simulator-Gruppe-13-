#pragma once
#include "PageReplacementStrategy.h"

// First In First Out (FIFO):
// Die älteste Seite im Speicher wird ersetzt, unabhängig davon, ob sie kürzlich verwendet wurde.
// Einfach zu implementieren, aber anfällig für hohe Page-Fault-Raten.

class FIFOReplacement : public PageReplacementStrategy {
public:
    void replacePage(ED209& memoryManager, int newPage) override;
};
