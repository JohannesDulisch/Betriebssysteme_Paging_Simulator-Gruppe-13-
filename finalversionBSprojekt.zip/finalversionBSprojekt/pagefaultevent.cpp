#include "PageFaultEvent.h"
#include <iostream>

PageFaultEvent::PageFaultEvent(int processId, int pageNumber, int timestamp)
    : Event([=]() {
        std::cout << "[Time " << timestamp << "] ❌ Page Fault bei Prozess "
                  << processId << ", Seite " << pageNumber << ".\n";
    }, timestamp) {}
