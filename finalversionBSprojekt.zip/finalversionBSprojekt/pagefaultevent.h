#ifndef PAGEFAULTEVENT_H
#define PAGEFAULTEVENT_H

#include "Event.h"

class PageFaultEvent : public Event {
public:
    PageFaultEvent(int processId, int pageNumber, int timestamp);
};

#endif // PAGEFAULTEVENT_H
