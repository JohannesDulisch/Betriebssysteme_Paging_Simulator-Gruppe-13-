#include "PageLoadEvent.h"
#include <iostream>

PageLoadEvent::PageLoadEvent(int pageNumber, int timestamp)
    : Event([=]() {
        std::cout << "[Time " << timestamp << "] 📥 Seite " << pageNumber
                  << " wird in den Speicher geladen.\n";
    }, timestamp) {}
