#ifndef TLB_H
#define TLB_H

#include <vector>
#include "TLBEntry.h"

class TLB {
public:
    TLB(unsigned int size);
    TLBEntry* lookup(unsigned int pageNumber);
    void insert(unsigned int pageNumber, unsigned int frameNumber);

private:
    std::vector<TLBEntry> entries;
    unsigned int nextReplaceIndex;
};

#endif // TLB_H
