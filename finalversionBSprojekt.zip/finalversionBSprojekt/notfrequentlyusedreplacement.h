#pragma once
#include "PageReplacementStrategy.h"

// Not Frequently Used (NFU):
// Jede Seite hat einen Zähler, der bei jedem Zugriff erhöht wird.
// Die Seite mit dem kleinsten Zähler wird ersetzt.
// Problem: alte Seiten können dauerhaft hohe Zähler behalten.

class NotFrequentlyUsedReplacement : public PageReplacementStrategy {
public:
    void replacePage(ED209& memoryManager, int newPage) override;
};
