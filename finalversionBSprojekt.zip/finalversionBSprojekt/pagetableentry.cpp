#include "PageTableEntry.h"

PageTableEntry::PageTableEntry(unsigned int frameIndex)
    : pageFrameIndex(frameIndex), frameAttributes(0) {}
