#include "notfrequentlyusedreplacement.h"

NotFrequentlyUsedReplacement::NotFrequentlyUsedReplacement() {}
