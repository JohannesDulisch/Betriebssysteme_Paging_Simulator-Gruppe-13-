#pragma once
#include "ED209.h"

class PageReplacementStrategy {
public:
    virtual ~PageReplacementStrategy() = default;

    // Seite ersetzen: ED209 = Speicherverwaltung, newPage = einzuladende Seite
    virtual void replacePage(ED209& memoryManager, int newPage) = 0;
};
