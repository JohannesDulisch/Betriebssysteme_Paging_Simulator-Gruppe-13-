#include "PageTable.h"

PageTable::PageTable(unsigned int numPages, unsigned int numFrames) {
    entries.resize(numPages);
    for (unsigned int i = 0; i < numPages; ++i) {
        entries[i] = std::make_unique<PageTableEntry>(i % numFrames);
    }
}

PageTableEntry* PageTable::getEntry(unsigned int pageIndex) {
    if (pageIndex < entries.size())
        return entries[pageIndex].get();
    return nullptr;
}
