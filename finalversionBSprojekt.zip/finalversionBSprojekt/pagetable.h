#ifndef PAGETABLE_H
#define PAGETABLE_H

#include <vector>
#include <memory>
#include "PageTableEntry.h"

class PageTable {
public:
    PageTable(unsigned int numPages, unsigned int numFrames);
    PageTableEntry* getEntry(unsigned int pageIndex);

private:
    std::vector<std::unique_ptr<PageTableEntry>> entries;
};

#endif // PAGETABLE_H
