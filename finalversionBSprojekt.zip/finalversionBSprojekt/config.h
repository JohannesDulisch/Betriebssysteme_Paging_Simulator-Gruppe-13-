#ifndef CONFIG_H
#define CONFIG_H

#define PAGE_SIZE 256
#define VIRTUAL_MEMORY_SIZE (PAGE_SIZE * 64)       // 64 virtuelle Seiten
#define SYSTEM_MEMORY_SIZE (PAGE_SIZE * 8)         // 8 physische Frames
#define NUM_PAGES (VIRTUAL_MEMORY_SIZE / PAGE_SIZE)
#define NUM_PAGE_FRAMES (SYSTEM_MEMORY_SIZE / PAGE_SIZE)
#define TLB_SIZE 4

// Frame-Attribute
#define FRAME_TLB        0x01
#define FRAME_REFERENCED 0x02
#define FRAME_MODIFIED   0x04
#define FRAME_LOCKED     0x08

#endif // CONFIG_H
