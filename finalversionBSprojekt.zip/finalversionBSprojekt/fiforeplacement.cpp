#include "FIFOReplacement.h"

void FIFOReplacement::replacePage(ED209& memoryManager, int newPage) {


    //todo: implement
}
