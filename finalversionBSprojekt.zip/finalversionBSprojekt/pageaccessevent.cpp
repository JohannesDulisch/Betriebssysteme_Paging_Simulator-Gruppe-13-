#include "PageAccessEvent.h"
#include <iostream>

PageAccessEvent::PageAccessEvent(int processId, int pageNumber, int timestamp)
    : Event([=]() {
        std::cout << "[Time " << timestamp << "] Prozess " << processId
                  << " greift auf Seite " << pageNumber << " zu.\n";
    }, timestamp) {}
