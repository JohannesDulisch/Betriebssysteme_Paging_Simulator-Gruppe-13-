#include "secondchancereplacement.h"

SecondChanceReplacement::SecondChanceReplacement() {}
