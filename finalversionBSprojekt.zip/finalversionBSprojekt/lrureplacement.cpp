#include "LRUReplacement.h"

void LRUReplacement::replacePage(ED209& memoryManager, int newPage) {

    //todo: implement

}
