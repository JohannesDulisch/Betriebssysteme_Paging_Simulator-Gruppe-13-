#include "PageReplaceEvent.h"
#include <iostream>

PageReplaceEvent::PageReplaceEvent(int oldPage, int newPage, int timestamp)
    : Event([=]() {
        std::cout << "[Time " << timestamp << "] 🔄 Seite " << oldPage
                  << " wird durch Seite " << newPage << " ersetzt.\n";
    }, timestamp) {}
