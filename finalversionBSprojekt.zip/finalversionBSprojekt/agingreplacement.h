#pragma once
#include "PageReplacementStrategy.h"

// NFU mit Aging:
// Wie NFU, aber die Zähler werden regelmäßig nach rechts geschoben (Bit-Shifting).
// Dadurch "altern" Seiten und verlieren alte Zugriffswerte.
// Bessere Annäherung an LRU mit weniger Aufwand.

class AgingReplacement : public PageReplacementStrategy {
public:
    void replacePage(ED209& memoryManager, int newPage) override;
};
