#ifndef PROCESS_H
#define PROCESS_H

#include <memory>
#include "PageTable.h"

class Process {
public:
    Process(unsigned int pid, unsigned int numPages, unsigned int numFrames);
    unsigned int getPID() const;
    PageTable* getPageTable();

private:
    unsigned int pid;
    std::unique_ptr<PageTable> pageTable;
};

#endif // PROCESS_H
