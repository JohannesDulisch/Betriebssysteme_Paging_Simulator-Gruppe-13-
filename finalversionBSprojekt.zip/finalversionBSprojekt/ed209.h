#ifndef ED209_H
#define ED209_H

#include <vector>
#include <memory>
#include "Process.h"
#include "MMU.h"

class ED209 {
public:
    ED209(unsigned int tlbSize);
    void addProcess(unsigned int pid, unsigned int numPages, unsigned int numFrames);
    unsigned int accessMemory(unsigned int pid, unsigned int pageNumber);

private:
    std::vector<std::unique_ptr<Process>> processes;
    MMU mmu;
};

#endif // ED209_H
