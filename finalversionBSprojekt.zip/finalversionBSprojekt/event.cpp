//
// Created by Markus Springer on 25.03.16.
//

#include "Event.h"

void Event::processEvent() {
    function();
}
