#ifndef TLBENTRY_H
#define TLBENTRY_H

class TLBEntry {
public:
    unsigned int pageNumber;
    unsigned int frameNumber;
    bool valid;

    TLBEntry(unsigned int page = 0, unsigned int frame = 0, bool isValid = false);
};

#endif // TLBENTRY_H
