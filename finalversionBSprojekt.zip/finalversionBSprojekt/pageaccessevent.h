#ifndef PAGEACCESSEVENT_H
#define PAGEACCESSEVENT_H

#include "Event.h"

class PageAccessEvent : public Event {
public:
    PageAccessEvent(int processId, int pageNumber, int timestamp);
};

#endif // PAGEACCESSEVENT_H
