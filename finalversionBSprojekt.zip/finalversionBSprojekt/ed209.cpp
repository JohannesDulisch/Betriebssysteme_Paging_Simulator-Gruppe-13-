#include "ED209.h"

ED209::ED209(unsigned int tlbSize) : mmu(tlbSize) {}

void ED209::addProcess(unsigned int pid, unsigned int numPages, unsigned int numFrames) {
    processes.push_back(std::make_unique<Process>(pid, numPages, numFrames));
}

unsigned int ED209::accessMemory(unsigned int pid, unsigned int pageNumber) {
    for (auto& process : processes) {
        if (process->getPID() == pid) {
            return mmu.translate(pageNumber, process->getPageTable());
        }
    }
    return -1; // Prozess nicht gefunden
}
