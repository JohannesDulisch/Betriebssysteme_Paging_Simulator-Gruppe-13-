#include "Process.h"

Process::Process(unsigned int pid, unsigned int numPages, unsigned int numFrames)
    : pid(pid), pageTable(std::make_unique<PageTable>(numPages, numFrames)) {}

unsigned int Process::getPID() const {
    return pid;
}

PageTable* Process::getPageTable() {
    return pageTable.get();
}
